package com.example.voicelock.activity

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.example.voicelock.databinding.ActivityPlaceScreenBinding
import com.google.android.gms.ads.MobileAds

class PlaceScreenActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlaceScreenBinding
    private var progress = 0
    private val handler = Handler(Looper.getMainLooper()) // Create a single handler instance

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlaceScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        MobileAds.initialize(this)


        init()
    }

    private fun init() {
        loadSeekBar()
    }

    private fun loadSeekBar() {
        val progressUpdater = object : Runnable {
            override fun run() {
                if (progress < 100) {
                    progress += 20 // Increment progress by 20
                    binding.sbSpaceScreen.progress = progress // Update SeekBar progress
                    handler.postDelayed(this, 500) // Repeat after 500ms
                } else {
                    // When progress reaches 100, navigate to MainActivity
                    startActivity(Intent(this@PlaceScreenActivity, LanguageActivity::class.java))
                    finish() // Optional: close the current activity
                }
            }
        }

        // Start the progress update loop
        handler.post(progressUpdater)
    }
}