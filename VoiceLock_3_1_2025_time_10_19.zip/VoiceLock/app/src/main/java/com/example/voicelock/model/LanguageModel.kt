package com.example.voicelock.model

class LanguageModel(
    val languageName: String = "",
    val languageCode: String = "",
    val iconResId: Int
) {
}