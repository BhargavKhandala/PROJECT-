package com.example.voicelock.Ads

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.example.voicelock.R
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback


class Constant {
    private val adRequest = AdRequest.Builder().build()
    var mInterstitialAd: InterstitialAd? = null
    var nextActivityName: Class<*>? = null // Store the next activity dynamically
    private var nativeAd: NativeAd? = null
    lateinit var rewardedAd: RewardedAd


    fun interstitialAdsLoad(context: Context) {
        InterstitialAd.load(
            context,
            "ca-app-pub-3940256099942544/1033173712",
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    mInterstitialAd = null
                }

                override fun onAdLoaded(interstitialAd: InterstitialAd) {
                    mInterstitialAd = interstitialAd

                    mInterstitialAd?.fullScreenContentCallback =
                        object : FullScreenContentCallback() {
                            override fun onAdDismissedFullScreenContent() {
                                nextActivity(context, nextActivityName!!)
                                interstitialAdsLoad(context)

                            }

                            override fun onAdFailedToShowFullScreenContent(p0: AdError) {
                                // Called when ad fails to show.
                                nextActivity(context, nextActivityName!!)
                                interstitialAdsLoad(context)
                            }

                            override fun onAdShowedFullScreenContent() {

                            }
                        }
                }
            })
    }

    fun showInterstitialAds(context: Context) {
        if (mInterstitialAd != null) {
            mInterstitialAd?.show(context as Activity)
        } else {
            nextActivity(context, nextActivityName!!)
        }
    }

    private fun nextActivity(context: Context, nextActivityName: Class<*>) {
        if (nextActivityName != null) {
            val intent = Intent(context, nextActivityName)
            context.startActivity(intent)
        }
    }

    fun loadNativeAds(context: Context, containerId: Int) {
        val adLoader =
            AdLoader.Builder(context, "ca-app-pub-3940256099942544/2247696110") // Test Ad Unit ID
                .forNativeAd { nativeAd ->
                    this.nativeAd = nativeAd
                    val adView = LayoutInflater.from(context)
                        .inflate(R.layout.native_ad_layout, null) as NativeAdView
                    populateNativeAdView(context as Activity, nativeAd, adView, containerId)

                    val frameLayout: FrameLayout = (context as Activity).findViewById(containerId)
                    frameLayout.removeAllViews()
                    frameLayout.addView(adView)
                    frameLayout.visibility = View.VISIBLE // Ensure the container is visible
                }
                .withAdListener(object : AdListener() {
                    override fun onAdFailedToLoad(adError: LoadAdError) {
                        Log.e("AdError", "Failed to load native ad: ${adError.message}")
                        Toast.makeText(
                            context,
                            "Ad failed to load: ${adError.message}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                })
                .withNativeAdOptions(
                    NativeAdOptions.Builder()
                        .build()
                )
                .build()

        adLoader.loadAd(AdRequest.Builder().build()) // Load the ad
    }

    private fun populateNativeAdView(
        context: Activity,
        nativeAd: NativeAd,
        adView: NativeAdView,
        containerId: Int
    ) {
        // Locate the view that will hold the headline, set its text, and use the
        // NativeAdView's headlineView property to register it.
        val headlineView = adView.findViewById<TextView>(R.id.ad_headline)
        val btnInstall = adView.findViewById<Button>(R.id.ad_call_to_action)
        headlineView.text = nativeAd.headline
        btnInstall.text = nativeAd.callToAction
        adView.headlineView = headlineView

        val mediaView = adView.findViewById<MediaView>(R.id.ad_image)
        adView.mediaView = mediaView
        adView.setNativeAd(nativeAd)

        val closeAdButton = adView.findViewById<ImageView>(R.id.imgCloseAds)
        val adContainer = (context as Activity).findViewById<ViewGroup>(containerId)
        closeAdButton.setOnClickListener {
            adContainer.visibility = View.GONE
            adContainer.removeAllViews()
            nativeAd.destroy()
        }
    }

    fun loadRewardedAd(context: Context) {
        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(
            context, "ca-app-pub-3940256099942544/5224354917", adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    nextActivity(context, nextActivityName!!)
                }

                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    rewardedAd.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdClicked() {
                            Log.d("TAG", "Ad was clicked.")
                        }

                        override fun onAdDismissedFullScreenContent() {
                            loadRewardedAd(context) // Reload a new ad
                            nextActivity(context, nextActivityName!!)
                        }


                        override fun onAdFailedToShowFullScreenContent(p0: AdError) {
                            nextActivity(context, nextActivityName!!)
                        }

                        override fun onAdImpression() {
                            Log.d("TAG", "Ad recorded an impression.")
                        }

                        override fun onAdShowedFullScreenContent() {
                            Log.d("TAG", "Ad showed fullscreen content.")
                        }

                    }
                }
            })
    }

    fun showRewardedAdFinish(context: Context) {
        if (::rewardedAd.isInitialized) {
            rewardedAd.show(context as Activity) { rewardItem: RewardItem ->
                rewardedAd.fullScreenContentCallback =
                    object : com.google.android.gms.ads.FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            super.onAdDismissedFullScreenContent()
                            loadRewardedAd(context)
                            showTheToastWallpaper(context)
                        }

                        override fun onAdFailedToShowFullScreenContent(p0: AdError) {
                            super.onAdFailedToShowFullScreenContent(p0)
                            showInterstitialAds(context)
                            showTheToastWallpaper(context)
                        }

                    }
            }
        } else {
            if (mInterstitialAd != null) {
                mInterstitialAd?.show(context as Activity)
                showTheToastWallpaper(context)
            } else {
                showTheToastWallpaper(context)
            }
        }
    }

    private fun showTheToastWallpaper(context: Context) {
        Toast.makeText(context, context.getString(R.string.wallpaper_is_set), Toast.LENGTH_SHORT).show()
        (context as Activity).finish()
    }

    fun showRewardedAd(context: Context) {
        if (::rewardedAd.isInitialized) {
            rewardedAd.show(context as Activity) { rewardItem: RewardItem ->
            }
            rewardedAd.fullScreenContentCallback =
                object : com.google.android.gms.ads.FullScreenContentCallback() {
                    override fun onAdClicked() {
                        super.onAdClicked()
                    }

                    override fun onAdFailedToShowFullScreenContent(p0: AdError) {
                        super.onAdFailedToShowFullScreenContent(p0)
                        if (mInterstitialAd != null) {
                            mInterstitialAd?.show(context)
                        } else {
                            nextActivity(context, nextActivityName!!)
                        }
                    }

                    override fun onAdDismissedFullScreenContent() {
                        super.onAdDismissedFullScreenContent()
                        nextActivity(context, nextActivityName!!)
                    }

                    override fun onAdShowedFullScreenContent() {
                        super.onAdShowedFullScreenContent()
                    }

                }

        } else {
            if (nextActivityName != null) {
                nextActivity(context, nextActivityName!!)
            }
        }
    }

    fun dialogBoxAdsRewarded(context: Context, onAdDismissed: () -> Unit) {
        if (mInterstitialAd != null) {
            mInterstitialAd?.show(context as Activity)
            // Handle the reward (optional)

            mInterstitialAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    // Notify that the ad has been dismissed
                    onAdDismissed()
                }
            }
        }
    }

}