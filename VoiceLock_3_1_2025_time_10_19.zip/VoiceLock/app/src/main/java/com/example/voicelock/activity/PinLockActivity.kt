package com.example.voicelock.activity

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.voicelock.Ads.Constant
import com.example.voicelock.Costant
import com.example.voicelock.EPreference.EPreferences
import com.example.voicelock.R
import com.example.voicelock.databinding.ActivityPinLockBinding

class PinLockActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPinLockBinding
    private var enteredPin = ""
    private var preEnteredPin = ""
    private val constant = Costant(this)
    private lateinit var Constant: Constant


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPinLockBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Constant = Constant()

        loadAds()

        init()
        addListener()
    }

    private fun loadAds() {
        Constant.interstitialAdsLoad(this)
    }

    private fun addListener() {
        binding.layoutTbPinLock.imgBackPress.setOnClickListener {
            finish()
        }
        digitClick()
        binding.imgCancelLastDigit.setOnClickListener { removeDigit() }
        binding.btnPinPsDone.setOnClickListener {
            if (enteredPin.length == 4) {
                // Handle 4-digit PIN completion
                preEnteredPin = enteredPin
                onPinComplete()
                binding.tvNewPin.text = getString(R.string.confirm_pin)
                binding.btnPinPsDone.visibility = View.GONE
                binding.btnConfirm.visibility = View.VISIBLE
            } else {
                Toast.makeText(this, getString(R.string.please_enter_pin), Toast.LENGTH_SHORT)
                    .show()
            }
        }

        binding.btnConfirm.setOnClickListener {
            if (enteredPin.length == 4) {
                // Handle 4-digit PIN completion
                if (preEnteredPin == enteredPin) {
                    Toast.makeText(this, getString(R.string.mach_password), Toast.LENGTH_SHORT)
                        .show()
                    EPreferences.getInstance(this).putString("pin_password", enteredPin)
                    Constant.dialogBoxAdsRewarded(this) {
                        constant.securingDeviceDialog()
                    }
                } else {
                    binding.tvNewPin.text = getString(R.string.enter_new_pin)
                    binding.btnPinPsDone.visibility = View.VISIBLE
                    binding.btnConfirm.visibility = View.GONE
                    Toast.makeText(this, getString(R.string.please_enter_pin), Toast.LENGTH_SHORT)
                        .show()
                }
                onPinComplete()
            } else {
                Toast.makeText(this, getString(R.string.please_enter_pin), Toast.LENGTH_SHORT)
                    .show()
            }
        }
    }

    private fun digitClick() {
        // Set click listeners for the PIN buttons
        binding.btnOnePin.llPinBg.setOnClickListener { addDigit("1") }
        binding.btnSecondPin.llPinBg.setOnClickListener { addDigit("2") }
        binding.btnThreePin.llPinBg.setOnClickListener { addDigit("3") }
        binding.btnFourPin.llPinBg.setOnClickListener { addDigit("4") }
        binding.btnFivePin.llPinBg.setOnClickListener { addDigit("5") }
        binding.btnSixPin.llPinBg.setOnClickListener { addDigit("6") }
        binding.btnSevenPin.llPinBg.setOnClickListener { addDigit("7") }
        binding.btnEightPin.llPinBg.setOnClickListener { addDigit("8") }
        binding.btnNinePin.llPinBg.setOnClickListener { addDigit("9") }
        binding.btnGiroPin.llPinBg.setOnClickListener { addDigit("0") }
    }

    @SuppressLint("MissingInflatedId")
    private fun securingDeviceDialog() {
        // Inflate the custom layout
        val dialogView = layoutInflater.inflate(R.layout.securing_your_device_dialog, null)

        // Create the dialog
        val dialog = android.app.AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)
            .create()

        dialog.window?.setBackgroundDrawableResource(R.drawable.securing_device_drawable)

        // Find views in the dialog
        val successMessage = dialogView.findViewById<TextView>(R.id.successMessage)
        val seekBar = dialogView.findViewById<SeekBar>(R.id.sbSpaceScreen)

        seekBar.setOnTouchListener { _, _ -> true }

        // Initialize SeekBar
        seekBar.max = 100
        seekBar.progress = 0

        // Start SeekBar progress animation for 5 seconds
        val duration = 5000 // 5 seconds in milliseconds
        val updateInterval = 50 // Interval for SeekBar updates in milliseconds

        val handler = Handler(Looper.getMainLooper())
        val startTime = System.currentTimeMillis()

        val runnable = object : Runnable {
            override fun run() {
                val elapsedTime = System.currentTimeMillis() - startTime
                val progress = (elapsedTime * 100 / duration).toInt()

                if (progress < 100) {
                    seekBar.progress = progress
                    handler.postDelayed(this, updateInterval.toLong())
                } else {
                    seekBar.progress = 100
                    dialog.dismiss()
                    successDialogBox()
                }
            }
        }

        handler.post(runnable)


        // Show the dialog
        dialog.show()
    }

    private fun successDialogBox() {

    }

    private fun init() {
        setTbText()
        setDigitText()
    }

    @SuppressLint("SetTextI18n")
    private fun setTbText() {
        binding.layoutTbPinLock.tvTbName.text = getString(R.string.set_pin_lock)
    }

    private fun addDigit(digit: String) {
        if (enteredPin.length < 4) {
            enteredPin += digit
            updatePinIndicators()
        }
    }

    private fun removeDigit() {
        if (enteredPin.isNotEmpty()) {
            enteredPin = enteredPin.dropLast(1)
            updatePinIndicators()
        }
    }

    private fun updatePinIndicators() {
        val pinLength = enteredPin.length

        // Update image resources for each PIN indicator
        binding.pinDigit1.setImageResource(if (pinLength > 0) R.drawable.pin_enter_ps_drawable else R.drawable.pin_enter_ps_blank_drawable)
        binding.pinDigit2.setImageResource(if (pinLength > 1) R.drawable.pin_enter_ps_drawable else R.drawable.pin_enter_ps_blank_drawable)
        binding.pinDigit3.setImageResource(if (pinLength > 2) R.drawable.pin_enter_ps_drawable else R.drawable.pin_enter_ps_blank_drawable)
        binding.pinDigit4.setImageResource(if (pinLength > 3) R.drawable.pin_enter_ps_drawable else R.drawable.pin_enter_ps_blank_drawable)
    }

    private fun onPinComplete() {
        // Action when the PIN is complete (e.g., verify PIN, navigate to another screen)
        // Example: Reset PIN for demonstration
        Log.d("pin", enteredPin)
        enteredPin = ""
        updatePinIndicators()
    }

    private fun setDigitText() {
        binding.btnOnePin.tvPinText.text = getString(R.string._1)
        binding.btnSecondPin.tvPinText.text = getString(R.string._2)
        binding.btnThreePin.tvPinText.text = getString(R.string._3)
        binding.btnFourPin.tvPinText.text = getString(R.string._4)
        binding.btnFivePin.tvPinText.text = getString(R.string._5)
        binding.btnSixPin.tvPinText.text = getString(R.string._6)
        binding.btnSevenPin.tvPinText.text = getString(R.string._7)
        binding.btnEightPin.tvPinText.text = getString(R.string._8)
        binding.btnNinePin.tvPinText.text = getString(R.string._9)
        binding.btnGiroPin.tvPinText.text = getString(R.string._0)
    }
}
