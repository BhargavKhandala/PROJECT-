package com.example.voicelock.activity

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.example.voicelock.Ads.Constant
import com.example.voicelock.Costant
import com.example.voicelock.EPreference.EPreferences
import com.example.voicelock.R
import com.example.voicelock.database.DatabaseHelper
import com.example.voicelock.databinding.ActivityWallpaperSetBinding
import kotlinx.coroutines.launch

class WallpaperSetActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWallpaperSetBinding
    private var imageUri = ""
    private var tableName = ""
    private var dbHandle: DatabaseHelper? = null
    private lateinit var constant :Constant

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWallpaperSetBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadAds()
        init()
        addListener()

    }

    private fun loadAds() {
        constant = Constant()
        constant.loadRewardedAd(this)
        constant.interstitialAdsLoad(this)
    }

    private fun addListener() {
        binding.imgBackPress.setOnClickListener {
            finish()
        }

        binding.imgDeleteWallpaper.setOnClickListener {
            deleteWallpaperImage()
        }

        binding.btnSetWallpaper.setOnClickListener {
                constant.showRewardedAdFinish(this)
            EPreferences.getInstance(this).putString(tableName, imageUri.toString())
        }
    }

    @SuppressLint("SuspiciousIndentation")
    private fun deleteWallpaperImage() {
        dbHandle!!.deleteTask(imageUri)
        val intent = Intent()
        intent.putExtra("delete_image", imageUri)
        setResult(Activity.RESULT_OK, intent)
        finish()

//        lifecycleScope.launch {
//            WallpaperDatabase.getDatabase(this@WallpaperSetActivity).wallpaperDao()
//                .deleteImage(imageUri)
//            Toast.makeText(this@WallpaperSetActivity, getString(R.string.delete_wallpaper),Toast.LENGTH_SHORT).show()
//
//            val intent = Intent()
//            intent.putExtra("delete_image",imageUri)
//            setResult(Activity.RESULT_OK,intent)
//
//            finish()
//        }
    }

    private fun init() {
        getImageUri()
        setFingerprintImg()
        dbHandle = DatabaseHelper(this, tableName)
        setTbText()
    }

    private fun setFingerprintImg() {
        if (tableName == "fingerprint")
            binding.imgFingerprint.visibility = View.VISIBLE
    }

    private fun setTbText() {
        binding.tvTbName.text = getString(R.string.set_walpaper)
    }

    private fun getImageUri() {
        imageUri = intent.getStringExtra("wallpaper_uri").toString()
        tableName = intent.getStringExtra("table_name").toString()

        if (imageUri.isNullOrEmpty()) {
            Log.e("WallpaperSetActivity", "imageUri is null or empty")
            return
        }

        Log.d("WallpaperSetActivity", "Received imageUri: $imageUri") // Check the format in Logcat

        try {
            Glide.with(this)
                .load(Uri.parse(imageUri)) // Convert back to Uri correctly
                .into(binding.imgWallpaper)
        } catch (e: Exception) {
            Log.e("WallpaperSetActivity", "Error loading image with Glide", e)
        }
    }


}