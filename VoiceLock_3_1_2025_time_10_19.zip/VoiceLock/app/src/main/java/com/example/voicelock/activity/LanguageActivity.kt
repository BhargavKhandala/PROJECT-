package com.example.voicelock.activity

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.voicelock.Ads.Constant
import com.example.voicelock.EPreference.EPreferences
import com.example.voicelock.R
import com.example.voicelock.adapter.LanguageAdapter
import com.example.voicelock.databinding.ActivityLanguageBinding
import com.example.voicelock.model.LanguageModel
import com.google.android.gms.ads.MobileAds
import java.util.Locale

class LanguageActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLanguageBinding
    private lateinit var constant: Constant
    private var languageModels: ArrayList<LanguageModel> = ArrayList()
    private lateinit var adapter: LanguageAdapter
    private var selectedLanguageCode: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLanguageBinding.inflate(layoutInflater)
        setContentView(binding.root)


        constant = Constant()
        constant.interstitialAdsLoad(this)

        init()
        addListener()
    }

    private fun init() {
        val change = intent.getStringExtra("settingInLanguage")
        if (change == "settingInChangeLanguage") {
        } else {
            checkLanguageSelect()
        }
        setRecycleView()
        addLanguageToAdapter()
    }

    private fun setRecycleView() {
        binding.rvLanguage.layoutManager = LinearLayoutManager(this)
    }

    private fun addListener() {
        // When the "Confirm" button (imgSelectLanguage) is clicked, update the locale and navigate.
        binding.imgSelectLanguage.setOnClickListener {
            binding.pbLanguage.visibility = View.VISIBLE
            if (selectedLanguageCode.isNotEmpty()) {
                setAppLocale(selectedLanguageCode)
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            } else {
                binding.pbLanguage.visibility = View.GONE
                Toast.makeText(
                    this,
                    getString(R.string.please_select_a_language), Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun addLanguageToAdapter() {
        languageModels.add(
            LanguageModel(
                getString(R.string.english_uk),
                "en-rGB",
                R.drawable.icon_english_uk
            )
        )
        languageModels.add(
            LanguageModel(
                getString(R.string.english_us),
                "en-rUS",
                R.drawable.icon_english_us
            )
        )
        languageModels.add(
            LanguageModel(
                getString(R.string.hindi),
                "hi",
                R.drawable.icon_india
            )
        )
        languageModels.add(
            LanguageModel(
                getString(R.string.tunisia),
                "ar-rTN",
                R.drawable.ic_turkish
            )
        )
        languageModels.add(
            LanguageModel(
                getString(R.string.saudi_arabia),
                "ar-rSA",
                R.drawable.ic_saudi_arabia
            )
        )
        languageModels.add(
            LanguageModel(
                getString(R.string.oman),
                "ar-rOM",
                R.drawable.ic_oman
            )
        )
        languageModels.add(
            LanguageModel(
                getString(R.string.bangla),
                "bn",
                R.drawable.ic_bangla
            )
        )

        adapter = LanguageAdapter(this, languageModels) { languageModel ->
            onLanguageSelected(languageModel)
        }
        binding.rvLanguage.adapter = adapter
    }

    private fun onLanguageSelected(language: LanguageModel) {
        selectedLanguageCode = language.languageCode
        binding.imgSelectLanguage.visibility = View.VISIBLE
        Toast.makeText(
            this,
            getString(R.string.selected_language, language.languageName), Toast.LENGTH_SHORT
        ).show()
    }

    private fun setAppLocale(languageCode: String) {
        val parts = languageCode.split("-")
        val locale = if (parts.size == 2) {
            Locale(parts[0], parts[1])
        } else {
            Locale(languageCode)
        }
        Locale.setDefault(locale)

        // Update the configuration with the new locale.
        val resources = resources
        val configuration: Configuration = resources.configuration
        configuration.setLocale(locale)
        resources.updateConfiguration(configuration, resources.displayMetrics)

        // Save the selected language for future use.
        EPreferences.getInstance(this).putString("select_language", languageCode)
    }

    private fun checkLanguageSelect() {
        val languageSelectCode = EPreferences.getInstance(this).getString("select_language", "")
        if (languageSelectCode.isNullOrEmpty()) {
            // No language selected; continue with the current activity.
        } else {
            setAppLocale(languageSelectCode)
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}
