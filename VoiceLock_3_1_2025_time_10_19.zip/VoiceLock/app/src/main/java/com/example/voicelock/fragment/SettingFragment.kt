package com.example.voicelock.fragment

import android.app.KeyguardManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.voicelock.R
import com.example.voicelock.activity.LanguageActivity
import com.example.voicelock.databinding.FragmentSettingBinding

class SettingFragment : Fragment() {

    private lateinit var binding: FragmentSettingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentSettingBinding.inflate(layoutInflater, container, false)
        init()
        addListener()
        return binding.root
    }

    private fun init() {
        setTbTet()
        setupSwitch()
    }

    private fun setupSwitch() {
        // Check if screen lock is enabled and set switch state
        binding.swOnOffLock.isChecked = isScreenLockSet()

        // Handle switch toggle
        binding.swOnOffLock.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                enableScreenLock()
            } else {
                disableScreenLock()
            }
        }
    }

    private fun isScreenLockSet(): Boolean {
        val keyguardManager =
            requireContext().getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        return keyguardManager.isKeyguardSecure
    }

    private fun enableScreenLock() {
        binding.pbSetting.visibility = View.VISIBLE
        binding.overlayView.visibility = View.VISIBLE
        val intent = Intent(Settings.ACTION_SECURITY_SETTINGS)
        startActivity(intent)
    }

    private fun disableScreenLock() {
        binding.pbSetting.visibility = View.VISIBLE
        binding.overlayView.visibility = View.VISIBLE
        val intent = Intent(Settings.ACTION_SECURITY_SETTINGS)
        startActivity(intent)
    }

    private fun setTbTet() {
        binding.layoutTb.tvTbName.text = getString(R.string.settings)
    }

    private fun addListener() {
        binding.layoutTb.imgBackPress.setOnClickListener {
            requireActivity().supportFragmentManager.popBackStack()
        }

        binding.rlSecurityPassword.setOnClickListener {
            binding.pbSetting.visibility = View.VISIBLE
            binding.overlayView.visibility = View.VISIBLE
            openSecurityPasswordFragment()
        }

        binding.rlShareApp.setOnClickListener {
            binding.pbSetting.visibility = View.VISIBLE
            binding.overlayView.visibility = View.VISIBLE
            shareApp()
        }

        binding.rlLanguage.setOnClickListener {
            val intent = Intent(requireContext(), LanguageActivity::class.java)
            intent.putExtra("settingInLanguage", "settingInChangeLanguage")
            requireContext().startActivity(intent)
        }

        binding.rlRate.setOnClickListener {
            rateApp()
        }

    }

    private fun rateApp() {
        val appPackageName = requireContext().packageName
        try {
            // Try to open the Play Store app.
            startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("market://details?id=$appPackageName")
                )
            )
        } catch (e: ActivityNotFoundException) {
            startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=$appPackageName")
                )
            )
        }
    }


    private fun openSecurityPasswordFragment() {
        requireActivity().supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, PasswordForgetAnsFragment())
            .addToBackStack(null)
            .commit()
    }

    private fun shareApp() {
        val appPackageName = requireContext().packageName
        val shareText =
            "Check out this amazing app: https://play.google.com/store/apps/details?id=$appPackageName"

        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, shareText)
        }
        startActivity(Intent.createChooser(shareIntent, "Share via"))
    }

    override fun onResume() {
        super.onResume()
        binding.swOnOffLock.setOnCheckedChangeListener(null)

        binding.swOnOffLock.isChecked = isScreenLockSet()

        binding.swOnOffLock.setOnCheckedChangeListener { _, isChecked ->
            enableScreenLock()
        }
        binding.pbSetting.visibility = View.GONE
        binding.overlayView.visibility = View.GONE
    }


}