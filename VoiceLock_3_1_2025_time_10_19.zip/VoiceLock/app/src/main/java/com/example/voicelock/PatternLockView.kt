package com.example.voicelock.views

import android.content.Context
import android.graphics.*
import android.text.BoringLayout
import android.util.AttributeSet
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.AdapterView.OnItemClickListener
import android.widget.Toast
import com.example.voicelock.EPreference.EPreferences
import com.google.firebase.crashlytics.buildtools.reloc.org.apache.http.Consts

class PatternLockView(context: Context, attrs: AttributeSet?) : View(context, attrs) {


    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }

    private val circlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private val selectedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.GREEN
        style = Paint.Style.FILL
    }

    private val pathPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.GREEN
        style = Paint.Style.STROKE
        strokeWidth = 10f
    }

    private val circles = Array(3) { Array(3) { PointF() } }
    private val selectedPoints = mutableListOf<PointF>()
    private val correctPattern = listOf(0, 3, 6) // Example pattern (can be saved securely)

    private var currentPath = Path()
    private var patternInput = mutableListOf<Int>()
    private var prePatternInput = mutableListOf<Int>()
    var onTextColorSet : OnItemClickListener? = null
    private var enabled : Boolean = true


    init {
        paint.strokeWidth = 5f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val radius = width / 50f

        // Draw circles
        for (i in 0..2) {
            for (j in 0..2) {
                val cx = (j + 1) * width / 4f
                val cy = (i + 1) * height / 4f
                circles[i][j] = PointF(cx, cy)

                // Change color if selected
                if (patternInput.contains(i * 3 + j)) {
                    canvas.drawCircle(cx, cy, radius, selectedPaint)
                } else {
                    canvas.drawCircle(cx, cy, radius, circlePaint)
                }
            }
        }

        // Draw path
        if (selectedPoints.isNotEmpty()) {
            canvas.drawPath(currentPath, pathPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!enabled) {
            // If the view is disabled, don't handle any touch events.
            return false
        }
        when (event.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                val x = event.x
                val y = event.y

                for (i in 0..2) {
                    for (j in 0..2) {
                        val point = circles[i][j]
                        if (Math.hypot((x - point.x).toDouble(), (y - point.y).toDouble()) < width / 10) {
                            val index = i * 3 + j
                            if (!patternInput.contains(index)) {
                                patternInput.add(index)
                                selectedPoints.add(point)
                                if (selectedPoints.size == 1) {
                                    currentPath.moveTo(point.x, point.y)
                                } else {
                                    currentPath.lineTo(point.x, point.y)
                                }
                                invalidate()
                            }
                        }
                    }
                }
            }

            MotionEvent.ACTION_UP -> {
                enabled = false
            }
        }
        return true
    }



    // Public method to reset the pattern immediately.
    fun firstDrawPattern() {
        prePatternInput = ArrayList(patternInput) // Create a copy of patternInput
        patternInput.clear()
        selectedPoints.clear()
        currentPath.reset()
        invalidate()
        enabled = true
    }

    fun confirm(){
        if (patternInput == prePatternInput){
            Toast.makeText(context,"Match",Toast.LENGTH_SHORT).show()
            onTextColorSet?.textColorSet(true)
            enabled = true
            EPreferences.getInstance(context).putString("patter_lock", patternInput.toString())
            onTextColorSet?.onPatternSuccess()
        } else{
            Toast.makeText(context,"Not Match",Toast.LENGTH_SHORT).show()
            resetPattern()
            onTextColorSet?.textColorSet(false)
            enabled = true
        }
    }

    fun resetPattern(){
        patternInput.clear()
        selectedPoints.clear()
        currentPath.reset()
        invalidate()
        enabled = true
    }

    fun clear(){
        prePatternInput.clear()
        patternInput.clear()
        selectedPoints.clear()
        currentPath.reset()
        invalidate()
        enabled = true
    }

    interface OnItemClickListener{
        fun textColorSet(value : Boolean)
        fun onPatternSuccess()  // Called when the pattern matches
    }
}
