package com.example.voicelock.fragment

import android.app.Activity
import android.app.Activity.RESULT_OK
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import com.example.voicelock.LockWallpaperAdapter
import com.example.voicelock.R
import com.example.voicelock.activity.WallpaperSetActivity
import com.example.voicelock.database.DatabaseHelper
import com.example.voicelock.database.model.TaskIsModel
import com.example.voicelock.databinding.FragmentLockThemesBinding


class LockThemesFragment : Fragment() {

    private lateinit var binding : FragmentLockThemesBinding
    private var lockType : String = ""
    private val REQUEST_IMAGE_PICK = 1001
    private lateinit var adapter : LockWallpaperAdapter
    private var imageList = mutableListOf<Uri>()
    private var taskIsModel : List<TaskIsModel> = ArrayList<TaskIsModel> ()
    private var dbHandle : DatabaseHelper? = null
    private lateinit var tableName: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
           lockType = it.getString("lock_themes_type").toString()
          }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentLockThemesBinding.inflate(layoutInflater, container, false)
        init()
        addListener()
        return binding.root
    }

    private fun init(){
        tableName = getTableName()
        dbHandle = DatabaseHelper(requireContext(), tableName)
        dbHandle!!.createTable(dbHandle!!.writableDatabase, tableName)
        setRecycleVIew()
        setTbText()
        fetchList()
    }

    private fun getTableName(): String {
        return when (lockType) {
            "Pin Lock" -> "PinLock"
            "Pattern Lock" -> "PatternLock"
            "Complex Lock" -> "ComplexLock"
            else -> "DefaultTable"
        }
    }

    private fun fetchList(){
        imageList.clear()
        taskIsModel = dbHandle!!.getAllTask()
        for (task in taskIsModel)
            task.image.let { imageUri ->
                imageList.add(Uri.parse(imageUri))
            }
        adapter.notifyDataSetChanged()
        Log.d("taskIsModel",taskIsModel.size.toString())
    }

    private fun insert(imageUri: Uri){
        val success : Boolean
        val task = TaskIsModel()
        task.image = imageUri.toString()
        success = dbHandle!!.addTask(task)
        if (success){
            Toast.makeText(requireContext(),"add : $imageList",Toast.LENGTH_SHORT)
            Log.d("taskIsModel",success.toString())
        } else{
            Toast.makeText(requireContext(),"not",Toast.LENGTH_SHORT)
        }
    }

    private fun setRecycleVIew() {
        binding.rvGallery.layoutManager = GridLayoutManager(requireActivity(),2)
        adapter = LockWallpaperAdapter(requireContext(),imageList,object : LockWallpaperAdapter.OnItemClickListener {
            override fun onItemClick(imageUri: Uri) {
                val intent = Intent(requireContext(), WallpaperSetActivity::class.java).apply {
                    putExtra("wallpaper_uri", imageUri.toString()) // Pass URI as a string
                    putExtra("table_name", tableName) // Pass URI as a string
                }
                startActivityForResult(intent,1000)
            }
        })
        binding.rvGallery.adapter = adapter
    }

    private fun setTbText() {
        if (lockType == "Pin Lock"){
            binding.tvTbName.text = getString(R.string.pin_lock_themes)
        }  else if (lockType == "Pattern Lock"){
            binding.tvTbName.text = getString(R.string.pattern_lock_themes)
        }  else if (lockType == "Complex Lock"){
            binding.tvTbName.text = getString(R.string.complex_lock_themes)
        }
    }

    private fun addListener() {
        binding.imgAddGallery.setOnClickListener {
            binding.pdWallpaperThemes.visibility = View.VISIBLE
            binding.overlayView.visibility = View.VISIBLE
            opeGallery()
        }

        binding.imgBackPress.setOnClickListener {
            requireActivity().supportFragmentManager.popBackStack()
        }
    }

    private fun opeGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        if (intent.resolveActivity(requireActivity().packageManager) != null) {
            startActivityForResult(intent, REQUEST_IMAGE_PICK)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_PICK && resultCode == RESULT_OK)
            data?.data?.let { uri ->
                imageList.add(uri)
                insert(uri)
                adapter.notifyDataSetChanged()
            }

        if (requestCode == 1000 && resultCode == Activity.RESULT_OK) {
            val deletedUri = data?.getStringExtra("delete_image") ?: return
            val uriToRemove = Uri.parse(deletedUri)

            Log.d("delete_image", "Deleted Image URI: $deletedUri")

            // Remove from Database
            val isDeleted = dbHandle?.deleteTask(deletedUri) ?: false

            if (isDeleted) {
                // Remove from the list and update UI
                imageList.remove(uriToRemove)
                adapter.notifyDataSetChanged()
                Log.d("delete_image", "Successfully removed from database")

                // Refresh list from the database
                fetchList()
            } else {
                Log.e("delete_image", "Failed to remove from database")
            }
        }}

    override fun onResume() {
        super.onResume()
        binding.pdWallpaperThemes.visibility = View.GONE
        binding.overlayView.visibility = View.GONE
    }

}