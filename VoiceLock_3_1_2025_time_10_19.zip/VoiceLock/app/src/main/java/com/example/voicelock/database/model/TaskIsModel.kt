package com.example.voicelock.database.model

class TaskIsModel {
    var image : String = ""
}