package com.example.voicelock.activity

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.voicelock.EPreference.EPreferences
import com.example.voicelock.R
import com.example.voicelock.databinding.FragmentPreviewBinding


class PreviewFragment : Fragment() {

    private lateinit var binding: FragmentPreviewBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentPreviewBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        init()
    }

    private fun init() {
        setDateTime()
        setFingerprint()
    }

    private fun setFingerprint() {
        val fingerprint = EPreferences.getInstance(requireContext()).getBoolean("fingerprint_status", true)
        if (fingerprint == true) {
            binding.layoutPreview.imgFingerprintLockOpen.visibility = View.VISIBLE
        } else {
            binding.layoutPreview.imgFingerprintLockOpen.visibility = View.GONE
        }
    }

    private fun setDateTime() {
        val dateTime = EPreferences.getInstance(requireContext()).getBoolean("date_time_show", true)
        if (dateTime == true) {
            binding.layoutPreview.tvCurrentDate.visibility = View.VISIBLE
            binding.layoutPreview.tvCurrentTime.visibility = View.VISIBLE
        } else {
            binding.layoutPreview.tvCurrentDate.visibility = View.GONE
            binding.layoutPreview.tvCurrentTime.visibility = View.GONE
        }
    }
}