package com.example.voicelock

import android.content.Context
import android.graphics.*
import android.text.BoringLayout
import android.util.AttributeSet
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.AdapterView.OnItemClickListener
import android.widget.Toast
import com.example.voicelock.EPreference.EPreferences

class PatterLockScreen(context: Context, attrs: AttributeSet?) : View(context, attrs) {

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 4f
        }

        private val circlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }

        private val selectedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.GREEN
            style = Paint.Style.FILL
        }

        private val pathPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.GREEN
            style = Paint.Style.STROKE
            strokeWidth = 10f
        }

        private val circles = Array(3) { Array(3) { PointF() } }
        private val selectedPoints = mutableListOf<PointF>()

        private var currentPath = Path()
        private var patternInput = mutableListOf<Int>()
        private var prePatternInput = mutableListOf<Int>()
        var homeLockScreen : OnItemClickListener? = null


        init {
            paint.strokeWidth = 5f
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)

            val radius = width / 50f

            // Draw circles
            for (i in 0..2) {
                for (j in 0..2) {
                    val cx = (j + 1) * width / 4f
                    val cy = (i + 1) * height / 4f
                    circles[i][j] = PointF(cx, cy)

                    // Change color if selected
                    if (patternInput.contains(i * 3 + j)) {
                        canvas.drawCircle(cx, cy, radius, selectedPaint)
                    } else {
                        canvas.drawCircle(cx, cy, radius, circlePaint)
                    }
                }
            }

            // Draw path
            if (selectedPoints.isNotEmpty()) {
                canvas.drawPath(currentPath, pathPaint)
            }
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    val x = event.x
                    val y = event.y

                    for (i in 0..2) {
                        for (j in 0..2) {
                            val point = circles[i][j]
                            if (Math.hypot((x - point.x).toDouble(), (y - point.y).toDouble()) < width / 10) {
                                val index = i * 3 + j
                                if (!patternInput.contains(index)) {
                                    patternInput.add(index)
                                    selectedPoints.add(point)
                                    if (selectedPoints.size == 1) {
                                        currentPath.moveTo(point.x, point.y)
                                    } else {
                                        currentPath.lineTo(point.x, point.y)
                                    }
                                    invalidate()
                                }
                            }
                        }
                    }
                }

                MotionEvent.ACTION_UP -> {
                    matchPassWord()
                }
            }
            return true
        }



        // Public method to reset the pattern immediately.
        fun matchPassWord() {
            val prePattern = EPreferences.getInstance(context).getString("patter_lock",null)
            if (patternInput.toString() == prePattern){
                homeLockScreen?.textColorSet(true)
            } else{
                clear()
                homeLockScreen?.textColorSet(false)
            }
        }

    private fun clear(){
        patternInput.clear()
        selectedPoints.clear()
        currentPath.reset()
        invalidate()
    }

    interface OnItemClickListener{
        fun textColorSet(value : Boolean)
    }

}