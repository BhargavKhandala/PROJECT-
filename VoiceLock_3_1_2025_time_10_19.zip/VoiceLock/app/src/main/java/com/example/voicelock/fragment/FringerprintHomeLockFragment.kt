package com.example.voicelock.fragment

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.example.voicelock.EPreference.EPreferences
import com.example.voicelock.R
import com.example.voicelock.databinding.FragmentFringerprintHomeLockBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FringerprintHomeLockFragment : Fragment() {

    private lateinit var binding: FragmentFringerprintHomeLockBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentFringerprintHomeLockBinding.inflate(inflater, container, false)

      init()
        return binding.root
    }

    private fun init() {
        val imgUri =  EPreferences.getInstance(requireContext()).getString("fingerprint", "null")
        Glide.with(requireContext())
            .load(Uri.parse(imgUri))
            .into(binding.imgFingerprintBg)

        // Update current time and date
        val currentDate = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
        val currentTime = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())

        // Set the current time and date dynamically
        binding.tvCurrentTime.text = currentTime
        binding.tvCurrentDate.text = currentDate

        // Handle fingerprint image click

        binding.imgFingerprint.setOnClickListener {
            if (isBiometricAvailable()) {
                authenticateFingerprint()
            } else {
                Toast.makeText(requireContext(), "Biometric authentication not available", Toast.LENGTH_SHORT).show()
            }
        }

        binding.layoutFingerprint.imgBackPress.setOnClickListener {
            requireActivity().supportFragmentManager.popBackStack()
        }
    }

    private fun isBiometricAvailable(): Boolean {
        val biometricManager = BiometricManager.from(requireContext())
        return biometricManager.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS
    }

    private fun authenticateFingerprint() {
        // Check if biometric authentication is available
        val biometricPrompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(requireContext()),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationError(
                    errorCode: Int,
                    errString: CharSequence
                ) {
                    super.onAuthenticationError(errorCode, errString)
                    Toast.makeText(requireContext(), "Authentication Error: $errString", Toast.LENGTH_SHORT).show()
                }

                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    val finishIntent = Intent("ACTION_FINISH_ALL")
                    requireContext().sendBroadcast(finishIntent)

                    // Close the fragment
                    requireActivity().finishAffinity() // This will close all associated activities

                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    Toast.makeText(requireContext(), "Authentication Failed", Toast.LENGTH_SHORT).show()
                }
            })

        // Build the biometric prompt
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Fingerprint Authentication")
            .setSubtitle("Please authenticate using your fingerprint")
            .setNegativeButtonText("Cancel")
            .setConfirmationRequired(false)  // This removes the extra confirmation step
            .build()

        // Show the biometric prompt
        biometricPrompt.authenticate(promptInfo)
    }
}
