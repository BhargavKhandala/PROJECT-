package com.example.voicelock.activity

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.voicelock.R
import com.example.voicelock.databinding.ActivityLockThemesBinding
import com.example.voicelock.fragment.LockThemesFragment

class LockThemesActivity : AppCompatActivity() {

    private lateinit var binding : ActivityLockThemesBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLockThemesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        init()
        addListener()

    }

    private fun init(){
        setTbText()
    }

    private fun setTbText() {
        binding.layoutTb.tvTbName.text = getString(R.string.set_lock_themes)
    }

    private fun addListener() {
        binding.layoutTb.imgBackPress.setOnClickListener {finish() }

        binding.rlPinLockTheme.setOnClickListener {
            openLockThemeFragment("Pin Lock")
        }

        binding.rlPatternLockTheme.setOnClickListener {
            openLockThemeFragment("Pattern Lock")
        }

        binding.rlComplexLockTheme.setOnClickListener {
            openLockThemeFragment("Complex Lock")
        }

    }

    private fun openLockThemeFragment(lockType : String) {
        val fragment = LockThemesFragment()
        val bundle = Bundle()
        bundle.putString("lock_themes_type",lockType)
        fragment.arguments = bundle

        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container,fragment)
            .addToBackStack(null)
            .commit()
    }
}