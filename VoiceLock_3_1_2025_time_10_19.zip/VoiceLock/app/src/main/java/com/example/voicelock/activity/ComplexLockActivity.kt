package com.example.voicelock.activity

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.voicelock.Ads.Constant
import com.example.voicelock.Costant
import com.example.voicelock.EPreference.EPreferences
import com.example.voicelock.R
import com.example.voicelock.databinding.ActivityComplexLockBinding
import kotlin.jvm.Throws

class ComplexLockActivity : AppCompatActivity() {

    private lateinit var binding: ActivityComplexLockBinding
    private var preComplexPs = ""
    private lateinit var Constant: Constant
    private val constant = Costant(this)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityComplexLockBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Constant = Constant()

        loadAds()


        // Automatically show keyboard when activity opens
        binding.edtComplex.requestFocus()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(binding.edtComplex, InputMethodManager.SHOW_IMPLICIT)

        init()
        addListener()
    }

    private fun loadAds() {
        Constant.interstitialAdsLoad(this)
    }

    private fun init(){
        binding.layoutTbPinLock.tvTbName.text = getString(R.string.set_complex_password)
    }

    private fun addListener() {
        binding.layoutTbPinLock.imgBackPress.setOnClickListener {
            finish()
        }
        binding.btnComplexPsDone.setOnClickListener {
            preComplexPs = binding.edtComplex.text.trim().toString()
            if (preComplexPs.isEmpty()) {
                Toast.makeText(this, getString(R.string.please_enter_pin), Toast.LENGTH_SHORT)
                    .show()
            } else {
                binding.edtComplex.hint = "Please re enter pin"
                binding.edtComplex.text = null
                binding.btnReComplexPsDone.visibility = View.VISIBLE
                binding.btnComplexPsDone.visibility = View.GONE
            }
        }

        binding.btnReComplexPsDone.setOnClickListener {
            val ComplexPs = binding.edtComplex.text.trim().toString()
            if (ComplexPs.isEmpty()) {
                Toast.makeText(this, getString(R.string.please_enter_pin), Toast.LENGTH_SHORT)
                    .show()
            } else {
                if (ComplexPs == preComplexPs) {
                    EPreferences.getInstance(this).putString("Complex_lock_password", preComplexPs)
                    Constant.dialogBoxAdsRewarded(this) {
                        constant.securingDeviceDialog()
                    }                } else {
                    Toast.makeText(this,
                        getString(R.string.not_match_complex_password_try_again), Toast.LENGTH_SHORT)
                        .show()
                    binding.edtComplex.text = null
                    binding.edtComplex.hint = getString(R.string.please_enter_pin)
                    binding.btnComplexPsDone.visibility = View.VISIBLE
                    binding.btnReComplexPsDone.visibility = View.GONE
                }
            }
        }
    }

    @SuppressLint("MissingInflatedId")
    private fun securingDeviceDialog() {
        // Inflate the custom layout
        val dialogView = layoutInflater.inflate(R.layout.securing_your_device_dialog, null)

        // Create the dialog
        val dialog = android.app.AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)
            .create()

        dialog.window?.setBackgroundDrawableResource(R.drawable.securing_device_drawable)

        // Find views in the dialog
        val successMessage = dialogView.findViewById<TextView>(R.id.successMessage)
        val seekBar = dialogView.findViewById<SeekBar>(R.id.sbSpaceScreen)

        seekBar.setOnTouchListener { _, _ -> true }

        // Initialize SeekBar
        seekBar.max = 100
        seekBar.progress = 0

        // Start SeekBar progress animation for 5 seconds
        val duration = 3000 // 5 seconds in milliseconds
        val updateInterval = 50 // Interval for SeekBar updates in milliseconds

        val handler = Handler(Looper.getMainLooper())
        val startTime = System.currentTimeMillis()

        val runnable = object : Runnable {
            override fun run() {
                val elapsedTime = System.currentTimeMillis() - startTime
                val progress = (elapsedTime * 100 / duration).toInt()

                if (progress < 100) {
                    seekBar.progress = progress
                    handler.postDelayed(this, updateInterval.toLong())
                } else {
                    seekBar.progress = 100
                    dialog.dismiss()
                    successDialog()
                }
            }
        }

        handler.post(runnable)


        // Show the dialog
        dialog.show()
    }

    private fun successDialog() {
        // Inflate the custom layout
        val dialogView = layoutInflater.inflate(R.layout.seccess_dialog, null)

        // Create the dialog
        val dialog = android.app.AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)
            .create()

        dialog.window?.setBackgroundDrawableResource(R.drawable.securing_device_drawable)
        val btnSuccess = dialogView.findViewById<Button>(R.id.btnContinueDialog)
        btnSuccess.setOnClickListener {
            dialog.dismiss()
            finish()
        }

        dialog.show()
    }
}