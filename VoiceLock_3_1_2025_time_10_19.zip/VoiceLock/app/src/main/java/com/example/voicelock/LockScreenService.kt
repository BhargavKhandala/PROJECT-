package com.example.voicelock

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.voicelock.activity.LockScreenActivity

class LockScreenService : Service() {
        private val screenReceiver = object : BroadcastReceiver() {
            @RequiresApi(Build.VERSION_CODES.O)
            override fun onReceive(context: Context, intent: Intent) {
                if (intent.action == Intent.ACTION_USER_PRESENT) {
                    val lockIntent = Intent(context, LockScreenActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    }
                    context.startActivity(lockIntent)
                }
            }
        }

        override fun onCreate() {
            super.onCreate()
            registerReceiver(screenReceiver, IntentFilter(Intent.ACTION_USER_PRESENT))
            startForegroundServiceWithNotification()
        }

        @SuppressLint("ForegroundServiceType")
        private fun startForegroundServiceWithNotification() {
            // Create a notification channel for Android 8.0 and higher
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channelId = "lockscreen_service"
                val channel = NotificationChannel(
                    channelId,
                    "Lock Screen",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Lock screen service notification"
                }
                val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.createNotificationChannel(channel)
            }

            // Build the notification
            val notification = NotificationCompat.Builder(this, "lockscreen_service")
                .setContentTitle("Lock Screen Active")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .setOngoing(true) // Make the notification persistent
                .build()

            // Start the service in the foreground
            startForeground(1, notification)
        }

        override fun onDestroy() {
            super.onDestroy()
            Log.d("LockScreenService", "Service Destroyed")
            unregisterReceiver(screenReceiver)
        }

        override fun onBind(intent: Intent?): IBinder? = null
    }