package com.example.voicelock.activity

import android.graphics.Color
import android.os.Bundle
import android.service.autofill.OnClickAction
import android.view.View
import android.widget.AdapterView.OnItemClickListener
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.voicelock.Ads.Constant
import com.example.voicelock.Costant
import com.example.voicelock.R
import com.example.voicelock.databinding.ActivityPattenLockBinding
import com.example.voicelock.views.PatternLockView
import com.google.firebase.crashlytics.buildtools.reloc.org.apache.http.Consts

class PattenLockActivity : AppCompatActivity(), PatternLockView.OnItemClickListener {

    private lateinit var binding: ActivityPattenLockBinding
    private lateinit var costant: Costant
    private lateinit var Constant: Constant
    private val constant = Costant(this)



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPattenLockBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Constant = Constant()

        loadAds()

        init()
        addListener()

    }

    private fun loadAds() {
        Constant.interstitialAdsLoad(this)
    }

    private fun init() {
        costant = Costant(this)
        binding.patternLockView.onTextColorSet = this
        setTbText()
    }

    private fun setTbText() {
        binding.layoutTb.tvTbName.text = getString(R.string.set_pattern_lock)
    }

    private fun addListener() {
        binding.layoutTb.imgBackPress.setOnClickListener {
            finish()
        }

        binding.btnPatternClear.setOnClickListener {
            binding.patternLockView.clear()
        }

        binding.btnPatternNext.setOnClickListener {
            binding.btnPatternNext.visibility = View.GONE
            binding.btnPatternConfirm.visibility = View.VISIBLE
            binding.btnPatternClear.visibility = View.GONE

            binding.tvPassword.text = getString(R.string.draw_patter_again_to_confirm)
            binding.patternLockView.firstDrawPattern()
            binding.tvPassword.text = getString(R.string.draw_patter_again_to_confirm)
            binding.tvPassword.setTextColor(Color.WHITE)
        }

        binding.btnPatternConfirm.setOnClickListener {
            binding.patternLockView.confirm()
        }
    }

    override fun textColorSet(value: Boolean) {
        if (value) {
            binding.tvPassword.text = getString(R.string.your_new_pattern)
            binding.tvPassword.setTextColor(Color.WHITE)
        } else {
            binding.tvPassword.text = getString(R.string.wrong_pattern)
            binding.tvPassword.setTextColor(Color.RED)
        }
    }

    override fun onPatternSuccess() {
        Constant.dialogBoxAdsRewarded(this) {
            constant.securingDeviceDialog()
        }    }


}