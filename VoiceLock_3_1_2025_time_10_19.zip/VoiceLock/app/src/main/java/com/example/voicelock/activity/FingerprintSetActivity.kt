package com.example.voicelock.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.voicelock.EPreference.EPreferences
import com.example.voicelock.R
import com.example.voicelock.databinding.ActivityFingerprintSetBinding
import com.example.voicelock.fragment.FingerprintThemeFragment

class FingerprintSetActivity : AppCompatActivity() {

    private lateinit var binding : ActivityFingerprintSetBinding

    @RequiresApi(Build.VERSION_CODES.P)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFingerprintSetBinding.inflate(layoutInflater)
        setContentView(binding.root)

        init()
        addListener()
    }

    @RequiresApi(Build.VERSION_CODES.P)
    private fun addListener() {
        imageToBack()
        switchButton()
        binding.rlChangeFingerprint.setOnClickListener {
            binding.pbFingerprint.visibility = View.VISIBLE
            binding.overlayView.visibility = View.VISIBLE // Disable interaction
            addFingerprintInSetting()
        }
        binding.rlChangeTheme.setOnClickListener {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, FingerprintThemeFragment())
                .addToBackStack(null)
                .commit()
        }
    }

    @RequiresApi(Build.VERSION_CODES.P)
    private fun addFingerprintInSetting() {
        val intent = Intent(android.provider.Settings.ACTION_FINGERPRINT_ENROLL)
        startActivity(intent)
    }


    private fun imageToBack() {
        binding.layoutTbPinLock.imgBackPress.setOnClickListener {
            finish()
        }
    }

    @SuppressLint("SetTextI18n")
    private fun switchButton() {
        binding.sbLock.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                binding.tvSwitchOnOff.text = "${getString(R.string.status)} ${getString(R.string.on)}"
                EPreferences.getInstance(this).putBoolean("fingerprint_status", true)
            } else {
                binding.tvSwitchOnOff.text = "${getString(R.string.status)} ${getString(R.string.off)}"
                EPreferences.getInstance(this).putBoolean("fingerprint_status", false)
            }
        }
    }

    private fun init(){
        setTbText()
        setSwitchButton()
    }

    private fun setTbText() {
        binding.layoutTbPinLock.tvTbName.text = getString(R.string.fingerprint_set)
    }

    private fun setSwitchButton() {
       val fingerprint = EPreferences.getInstance(this).getBoolean("fingerprint_status", true)
        binding.sbLock.isChecked = fingerprint
    }

    override fun onResume() {
        super.onResume()
        binding.pbFingerprint.visibility = View.GONE
        binding.overlayView.visibility = View.GONE
    }

}