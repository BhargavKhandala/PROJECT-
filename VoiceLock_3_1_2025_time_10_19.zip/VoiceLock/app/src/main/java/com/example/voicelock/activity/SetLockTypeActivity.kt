package com.example.voicelock.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.voicelock.R
import com.example.voicelock.databinding.ActivitySelLockTypeBinding

class SetLockTypeActivity : AppCompatActivity() {

    private lateinit var binding : ActivitySelLockTypeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySelLockTypeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        init()
        addListener()
    }

    private fun addListener() {
        binding.layoutTb.imgBackPress.setOnClickListener {
            finish()
        }
        binding.layoutVoice.rlHomeIcon.setOnClickListener {
            startActivity(Intent(this, VoiceLoockActivity::class.java))
        }
        binding.layoutPinLock.rlHomeIcon.setOnClickListener {
            startActivity(Intent(this, PinLockActivity::class.java))
        }
        
        binding.layoutPattenLock.rlHomeIcon.setOnClickListener { 
            startActivity(Intent(this,PattenLockActivity::class.java))
        }
        
        binding.layoutComplexLock.rlHomeIcon.setOnClickListener {
            startActivity(Intent(this, ComplexLockActivity::class.java))
        }
    }



        private fun init(){
        setupLayoutIcons()
    }

    @SuppressLint("SetTextI18n")
    private fun setupLayoutIcons() {
        //voice lock
        val layoutVoice = binding.layoutVoice
        val imgLochTheme = layoutVoice.imgLayoutLock
        val tvLockTheme = layoutVoice.tvLayoutIconName
        imgLochTheme.setImageResource(R.drawable.ic_voice_icon)
        tvLockTheme.text = getString(R.string.voice_lock)

        //pin lock
        val layoutPinLock = binding.layoutPinLock
        val imgPinLock = layoutPinLock.imgLayoutLock
        val tvPinLockName = layoutPinLock.tvLayoutIconName
        imgPinLock.setImageResource(R.drawable.ic_pin_lock)
        tvPinLockName.text = getString(R.string.pin_lock)

        //complex Lock
        val layoutComplexLock = binding.layoutComplexLock
        val imgComplexLockTheme = layoutComplexLock.imgLayoutLock
        val tvComplexLockTheme = layoutComplexLock.tvLayoutIconName
        imgComplexLockTheme.setImageResource(R.drawable.complex_password)
        tvComplexLockTheme.text = getString(R.string.complex_lock)

        //Pattern lock
        val layoutPattenLock = binding.layoutPattenLock
        val imgPatternLock = layoutPattenLock.imgLayoutLock
        val tvPatternLockName = layoutPattenLock.tvLayoutIconName
        imgPatternLock.setImageResource(R.drawable.ic_pattern_lock)
        tvPatternLockName.text = getString(R.string.pattern_lock)

    }

}