package com.example.voicelock.EPreference

import android.content.Context
import android.content.SharedPreferences

class EPreferences private constructor(context: Context, prefName: String, mode: Int) {

    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences(prefName, mode)

    companion object {
        const val TAG_NAME = "tag_name"
        private const val PREF_NAME = "test_pref"
        private const val MODE_PRIVATE = Context.MODE_PRIVATE

        // Define the SWITCH constant here
        const val SWITCH = "switch_key"

        @Volatile
        private var instance: EPreferences? = null

        fun getInstance(context: Context): EPreferences {
            return instance ?: synchronized(this) {
                instance ?: EPreferences(context, PREF_NAME, MODE_PRIVATE).also { instance = it }
            }
        }
    }

    // GET Values
    fun getBoolean(key: String, defaultValue: Boolean): Boolean {
        return sharedPreferences.getBoolean(key, defaultValue)
    }

    fun getString(key: String, defaultValue: String?): String? {
        return sharedPreferences.getString(key, defaultValue)
    }

    fun getInt(key: String, defaultValue: Int): Int {
        return sharedPreferences.getInt(key, defaultValue)
    }

    // PUT Values
    fun putString(key: String, value: String): Int {
        sharedPreferences.edit().putString(key, value).apply()
        return 0
    }

    fun putBoolean(key: String, value: Boolean): Int {
        sharedPreferences.edit().putBoolean(key, value).apply()
        return 0
    }

    fun putInt(key: String, value: Int): Int {
        sharedPreferences.edit().putInt(key, value).apply()
        return 0
    }

    fun containsKey(key: String): Boolean {
        return sharedPreferences.contains(key)
    }

    fun removeKey(key: String) {
        sharedPreferences.edit().remove(key).apply()
    }
}
