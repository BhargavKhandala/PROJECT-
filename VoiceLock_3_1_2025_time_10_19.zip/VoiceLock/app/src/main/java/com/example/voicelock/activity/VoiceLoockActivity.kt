package com.example.voicelock.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import android.view.animation.Animation
import android.view.animation.ScaleAnimation
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.voicelock.EPreference.EPreferences
import com.example.voicelock.R
import com.example.voicelock.databinding.ActivityVoiceLoockBinding
import com.example.voicelock.fragment.PasswordForgetAnsFragment
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class VoiceLoockActivity : AppCompatActivity() {

    private lateinit var binding: ActivityVoiceLoockBinding
    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false
    private val handler = Handler(Looper.getMainLooper())
    private val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault()) // Format for time

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVoiceLoockBinding.inflate(layoutInflater)
        setContentView(binding.root)

        init()
        addListeners()
    }

    private fun init() {
        binding.layoutTb.tvTbName.text = getString(R.string.set_voice_lock)
        updateCurrentTime()
        setOldVoicePs()
    }

    @SuppressLint("SetTextI18n")
    private fun setOldVoicePs() {
        val fingerprintOldPs =
            EPreferences.getInstance(this).getString("fingerprint_voice_ps", "null")
        binding.tvRecordVoicePw.text =
            "${getString(R.string.record_your_old_voice_password)} : ${fingerprintOldPs}"
    }

    private fun updateCurrentTime() {
        val updateRunnable = object : Runnable {
            override fun run() {
                // Get the current time and format it
                val currentTime = timeFormat.format(Date())
                // Update the TextView
                binding.tvCurrentTime.text = currentTime
                // Schedule the next update after 1 minute
                handler.postDelayed(this, 60000)
            }
        }
        // Initial run
        handler.post(updateRunnable)
    }


    private fun addListeners() {
        binding.ivVoiceIcon.setOnClickListener { view ->
            if (isListening) {
                stopVoiceRecognition()
            } else {
                startVoiceRecognition(view)
            }
        }

        binding.imgPwAns.setOnClickListener {
            openPasswordFragment()
        }

        binding.layoutTb.imgBackPress.setOnClickListener {
            finish()
        }

    }

    private fun openPasswordFragment() {
        val fragment = PasswordForgetAnsFragment()

        // Begin fragment transaction
        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(
            R.id.fragment_container,
            fragment
        ) // Replace the container with the new fragment
        transaction.addToBackStack(null) // Optional: add this transaction to the back stack for back navigation
        transaction.commit()
    }

    private fun startRippleAnimation(view: View) {
        val outerRippleView = binding.rippleView

        // Scale animation to grow the circle
        val scaleAnimation = ScaleAnimation(
            0.6f, 1f, // Start at original size (200dp), scale to 2x (400dp)
            0.6f, 1f,
            Animation.RELATIVE_TO_SELF, 0.5f,
            Animation.RELATIVE_TO_SELF, 0.5f
        ).apply {
            duration = 1000 // Duration of animation
            repeatMode = Animation.RESTART
            repeatCount = Animation.INFINITE
        }

        outerRippleView.visibility = View.VISIBLE
        outerRippleView.startAnimation(scaleAnimation)
    }

    private fun stopRippleAnimation() {
        val outerRippleView = binding.rippleView
        outerRippleView.clearAnimation()
        outerRippleView.visibility = View.INVISIBLE
    }

    private fun startVoiceRecognition(view: View) {

        resetRecognizer() // Ensure any existing recognizer is released
        isListening = true

        startRippleAnimation(view)

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                Log.d("VoiceLock", "Ready for speech")
            }

            override fun onBeginningOfSpeech() {
                Log.d("VoiceLock", "Speech started")
            }

            override fun onRmsChanged(rmsdB: Float) {}

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                Log.d("VoiceLock", "Speech ended")
                stopRippleAnimation()
            }

            override fun onError(error: Int) {
                Log.e("VoiceLock", "Error occurred: $error")
                stopVoiceRecognition()
            }

            @SuppressLint("SetTextI18n")
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    val spokenText = matches[0]
                    binding.tvRecordVoicePw.text =
                        "${getString(R.string.voice_password)} : ${spokenText}"
                    EPreferences.getInstance(this@VoiceLoockActivity)
                        .putString("fingerprint_voice_ps", spokenText)
                    Log.d("VoiceLock", "Recognized text: $spokenText")
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {}

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
        }

        speechRecognizer?.startListening(intent)
    }

    private fun resetRecognizer() {
        speechRecognizer?.destroy()
        speechRecognizer = null
    }

    private fun stopVoiceRecognition() {
        isListening = false
        stopRippleAnimation()

        speechRecognizer?.apply {
            stopListening()
            cancel()
            destroy()
        }
        speechRecognizer = null
    }

    override fun onDestroy() {
        super.onDestroy()
        resetRecognizer()
    }
}
