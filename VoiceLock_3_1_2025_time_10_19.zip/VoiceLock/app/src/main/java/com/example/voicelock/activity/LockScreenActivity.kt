package com.example.voicelock.activity

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.Animation
import android.view.animation.ScaleAnimation
import android.view.inputmethod.InputMethodManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.example.voicelock.EPreference.EPreferences
import com.example.voicelock.R
import com.example.voicelock.databinding.ActivityLockScreenBinding
import com.example.voicelock.fragment.FringerprintHomeLockFragment
import com.example.voicelock.fragment.PasswordForgetAnsFragment
import java.text.SimpleDateFormat
import java.util.*

class LockScreenActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLockScreenBinding
    private val handler = Handler(Looper.getMainLooper()) // To update the time dynamically
    private var isListening = false
    private var speechRecognizer: SpeechRecognizer? = null
    private var spinnerPosition: String? = ""
    private var spinnerSelectName: String? = "0"
    private var isPasswordMatched = false

    private val updateTimeRunnable = object : Runnable {
        override fun run() {
            updateCurrentTimeAndDate()
            handler.postDelayed(this, 1000) // Update every second
        }
    }

    private val finishReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent?) {
            if (intent?.action == "ACTION_FINISH_ALL") {
                isPasswordMatched = true
                finish()
            }
        }
    }


    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Set the activity to appear as a system alert window (overlay)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                android.graphics.PixelFormat.TRANSLUCENT
            )
            window.attributes = params
        }

        binding = ActivityLockScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Register the receiver with the appropriate flag
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // For Android 13 and above, specify RECEIVER_NOT_EXPORTED or RECEIVER_EXPORTED
            registerReceiver(
                finishReceiver,
                IntentFilter("ACTION_FINISH_ALL"),
                Context.RECEIVER_EXPORTED
            )
        } else {
            // For older versions, use the default behavior
            registerReceiver(finishReceiver, IntentFilter("ACTION_FINISH_ALL"))
        }

        init()
        addListeners()
    }

    private fun init() {
        setWallpaper()
        setFingerprint()
        setDateTime()
        updateCurrentTimeAndDate() // Initial call to display the time and date
    }

    private fun setWallpaper() {
        val wallpaperUri = EPreferences.getInstance(this).getString("lockWallpaper", "").toString()
        Log.d("wallpaperImage", "Image : ${wallpaperUri}")
        if (wallpaperUri.isNullOrEmpty()) {
            Log.e("WallpaperSetActivity", "imageUri is null or empty")
            return
        }

        Log.d(
            "WallpaperSetActivity",
            "Received imageUri: $wallpaperUri"
        ) // Check the format in Logcat

        try {
            Glide.with(this)
                .load(Uri.parse(wallpaperUri)) // Convert back to Uri correctly
                .into(binding.imgWallpaper)
        } catch (e: Exception) {
            Log.e("WallpaperSetActivity", "Error loading image with Glide", e)
        }

//        val uri = Uri.parse(wallpaperUri)
//
//        val drawable = Glide.with(this)
//            .load(uri)
//            .submit()
//            .get() // Get the drawable synchronously
//
//        binding.rlLockScren.background = drawable
    }

    private fun setDateTime() {
        val setDateTime = EPreferences.getInstance(this).getBoolean("date_time_show", true)
        if (setDateTime == true) {
            binding.tvCurrentDate.visibility = View.VISIBLE
            binding.tvCurrentTime.visibility = View.VISIBLE
        } else {
            binding.tvCurrentDate.visibility = View.GONE
            binding.tvCurrentTime.visibility = View.GONE
        }
    }

    private fun setFingerprint() {
        val fingerprintStatus =
            EPreferences.getInstance(this).getBoolean("fingerprint_status", true)
        if (fingerprintStatus == true) {
            binding.imgFingerprintLockOpen.visibility = View.VISIBLE
        } else
            binding.imgFingerprintLockOpen.visibility = View.GONE
    }

    private fun addListeners() {
        binding.ivVoiceIcon.setOnClickListener { view ->
            if (isListening) {
                stopVoiceRecognition()
            } else {
                startVoiceRecognition(view)
            }
        }

        // Pin Lock Image Click
        binding.llPinLock.setOnClickListener {
            navigateToActivity("Pin Lock")
        }

        // Pattern Lock Image Click
        binding.llPattenLock.setOnClickListener {
            navigateToActivity("Pattern Lock")
        }

        binding.llComplexLock.setOnClickListener {
            navigateToActivity("Complex Lock")
        }

        // Fingerprint Lock Icon Click
        binding.imgFingerprintLockOpen.setOnClickListener {
            openTheFingerprint()
        }

        // Forgot Password Text Click
        binding.tvForgotPassword.setOnClickListener {
            setTbText()
            setupSpinner()

            binding.rlHomeScreenToLock.visibility = View.GONE
            binding.rlForgotLockPs.visibility = View.VISIBLE
        }

        binding.btnForgotPw.setOnClickListener {
            checkPsMath()
        }
    }

    private fun openTheFingerprint() {
        val fragment = FringerprintHomeLockFragment()

        // Begin fragment transaction
        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(
            R.id.fragment_container,
            fragment
        ) // Replace the container with the new fragment
        transaction.addToBackStack(null) // Optional: add this transaction to the back stack for back navigation
        transaction.commit()
    }

    private fun checkPsMath() {
        val edtForgotPs = binding.edtForgotPsAns.text.trim().toString()
        val forgotPs =
            EPreferences.getInstance(this).getString("fingerprint_forget_password", "null")
        val spinnerPositionPs =
            EPreferences.getInstance(this).getString("fingerprint_spinner_position", "null")

        if (edtForgotPs.isNotEmpty()) {
            if (spinnerSelectName != "0") {
                if (spinnerPositionPs == spinnerPosition) {
                    if (edtForgotPs == forgotPs) {
                        finish()
                    } else {
                        Toast.makeText(
                            this,
                            getString(R.string.incorrect_password_please_try_again),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    Toast.makeText(
                        this,
                        getString(R.string.wrong_select_question_please_right_select_question),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } else {
                Toast.makeText(
                    this,
                    getString(R.string.please_select_question), Toast.LENGTH_SHORT
                ).show()
            }

        } else {
            Toast.makeText(
                this,
                getString(R.string.please_enter_forget_password_ans), Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun setTbText() {
        binding.layoutTb.tvTbName.text = getString(R.string.forgot_password)
        binding.layoutTb.imgBackPress.setOnClickListener {
            binding.rlHomeScreenToLock.visibility = View.VISIBLE
            binding.rlForgotLockPs.visibility = View.GONE
        }
    }

    private fun setupSpinner() {
        val items = resources.getStringArray(R.array.spinner_items)

        // Create a custom ArrayAdapter
        val adapter = object :
            ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            override fun getDropDownView(
                position: Int,
                convertView: View?,
                parent: ViewGroup
            ): View {
                val view = super.getDropDownView(position, convertView, parent)
                val textView = view.findViewById<TextView>(android.R.id.text1)

                // Set the text color for the dropdown items
                textView.setTextColor(
                    if (position == 0) ContextCompat.getColor(context, R.color.white)
                    else ContextCompat.getColor(context, R.color.white)
                )

                // Set padding for dropdown items (10dp converted to pixels)
                val padding = (10 * resources.displayMetrics.density).toInt()
                textView.setPadding(padding, padding, padding, padding)

                return view
            }

            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val view = super.getView(position, convertView, parent)
                val textView = view.findViewById<TextView>(android.R.id.text1)

                // Set text color for the currently selected item
                textView.setTextColor(ContextCompat.getColor(context, R.color.white))

                // Set padding for selected item (10dp converted to pixels)
                val padding = (10 * resources.displayMetrics.density).toInt()
                textView.setPadding(padding, padding, padding, padding)

                return view
            }

            override fun isEnabled(position: Int): Boolean {
                // Disable the first item (hint) from being selected
                return position != 0
            }
        }

        // Attach the adapter to the spinner
        binding.spinner.adapter = adapter

        // Handle item selection events
        binding.spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                if (position != 0) {
                    val selectedItem = items[position]
                    spinnerPosition = position.toString()
                    spinnerSelectName = selectedItem
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // No action needed
            }
        }
    }

    private fun stopVoiceRecognition() {
        isListening = false
        stopRippleAnimation()

        speechRecognizer?.apply {
            stopListening()
            cancel()
            destroy()
        }
        speechRecognizer = null
    }

    private fun startVoiceRecognition(view: View) {

        resetRecognizer() // Ensure any existing recognizer is released
        isListening = true

        startRippleAnimation(view)

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                Log.d("VoiceLock", "Ready for speech")
            }

            override fun onBeginningOfSpeech() {
                Log.d("VoiceLock", "Speech started")
            }

            override fun onRmsChanged(rmsdB: Float) {}

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                Log.d("VoiceLock", "Speech ended")
                stopRippleAnimation()
            }

            override fun onError(error: Int) {
                Log.e("VoiceLock", "Error occurred: $error")
                stopVoiceRecognition()
            }

            @SuppressLint("SetTextI18n")
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    val spokenText = matches[0]
                    val voicePs = EPreferences.getInstance(this@LockScreenActivity)
                        .getString("fingerprint_voice_ps", "null")
                    if (voicePs == spokenText) {
                        finish()
                    } else {
                        Toast.makeText(
                            this@LockScreenActivity,
                            getString(R.string.incorrect_password_please_try_again),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    Log.d("VoiceLock", "Recognized text: $spokenText")
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {}

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
        }

        speechRecognizer?.startListening(intent)
    }

    private fun resetRecognizer() {
        speechRecognizer?.destroy()
        speechRecognizer = null
    }

    private fun startRippleAnimation(view: View) {
        val outerRippleView = binding.rippleView

        // Scale animation to grow the circle
        val scaleAnimation = ScaleAnimation(
            0.6f, 1f, // Start at original size (200dp), scale to 2x (400dp)
            0.6f, 1f,
            Animation.RELATIVE_TO_SELF, 0.5f,
            Animation.RELATIVE_TO_SELF, 0.5f
        ).apply {
            duration = 1000 // Duration of animation
            repeatMode = Animation.RESTART
            repeatCount = Animation.INFINITE
        }

        outerRippleView.visibility = View.VISIBLE
        outerRippleView.startAnimation(scaleAnimation)
    }

    private fun stopRippleAnimation() {
        val outerRippleView = binding.rippleView
        outerRippleView.clearAnimation()
        outerRippleView.visibility = View.INVISIBLE
    }


    // Navigate to different activities based on lock type
    private fun navigateToActivity(lockType: String) {
        val intent = Intent(
            this,
            LockHomeScreenActivity::class.java
        ) // Replace `SomeActivity` with your target activity
        intent.putExtra("lock_type", lockType) // Pass lock type as an extra
        startActivity(intent)
    }

    // Update the current time and date
    private fun updateCurrentTimeAndDate() {
        val currentTime = Calendar.getInstance().time

        // Format current time
        val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
        val formattedTime = timeFormat.format(currentTime)

        // Format current date
        val dateFormat = SimpleDateFormat(
            "EEEE, dd MMMM yyyy",
            Locale.getDefault()
        ) // e.g., Monday, 25 January 2025
        val formattedDate = dateFormat.format(currentTime)

        // Update UI
        binding.tvCurrentTime.text = formattedTime
        binding.tvCurrentDate.text = formattedDate
    }

    override fun onResume() {
        super.onResume()
        handler.post(updateTimeRunnable) // Start updating time when activity is visible
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(updateTimeRunnable) // Stop updating time when activity is not visible
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(finishReceiver) // Unregister the receiver
    }


    override fun onBackPressed() {
        if (isPasswordMatched) {
            super.onBackPressed() // Allow back press only if password is correct
        } else {
            Toast.makeText(this, "Enter the correct password to exit", Toast.LENGTH_SHORT).show()
        }    }
}
