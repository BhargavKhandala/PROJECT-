package com.example.voicelock.adapter

import android.content.Context
import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.voicelock.databinding.ItemFingerprintImageWallpaperBinding

class FingerprintAdapter(private val context: Context,private val imageList : List<Uri>,private val onItemClick : OnItemClickListener
) : RecyclerView.Adapter<FingerprintAdapter.FingerprintImageViewHolder>() {

    class FingerprintImageViewHolder(
        private val binding: ItemFingerprintImageWallpaperBinding,
        private val context: Context,
        private val onItemClick: OnItemClickListener
    ) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(imageUri: Uri) {
            Glide.with(binding.root.context)
                .load(imageUri)
                .into(binding.imageView) // Load image using Glide

            binding.root.setOnClickListener {
                onItemClick.onItemClick(imageUri)
            }
        }
    }


    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): FingerprintAdapter.FingerprintImageViewHolder {
        val binding =
            ItemFingerprintImageWallpaperBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FingerprintImageViewHolder(binding,context,onItemClick)
    }

    override fun onBindViewHolder(
        holder: FingerprintAdapter.FingerprintImageViewHolder,
        position: Int
    ) {
        holder.bind(imageList[position])
    }

    override fun getItemCount(): Int = imageList.size

    interface OnItemClickListener{
        fun onItemClick(imageUri: Uri)
    }
}