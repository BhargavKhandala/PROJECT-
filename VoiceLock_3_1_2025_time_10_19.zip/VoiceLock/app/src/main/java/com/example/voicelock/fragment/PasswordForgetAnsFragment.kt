package com.example.voicelock.fragment

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.view.marginTop
import com.example.voicelock.EPreference.EPreferences
import com.example.voicelock.R
import com.example.voicelock.databinding.FragmentPasswordForgetAnsBinding

class PasswordForgetAnsFragment : Fragment() {
    private lateinit var binding: FragmentPasswordForgetAnsBinding
    private var spinnerPosition = 0
    private var spinnerSelectName: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentPasswordForgetAnsBinding.inflate(inflater, container, false)
        return binding.root // Return the root of the binding
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        init()
        addListener()
    }

    private fun init() {
        setTbLayout()
        setupSpinner()
    }

    @SuppressLint("SetTextI18n")
    private fun setTbLayout() {
        binding.layoutTb.tvTbName.text = getString(R.string.security_question)
    }

    private fun addListener() {
        binding.layoutTb.imgBackPress.setOnClickListener {
            requireActivity().supportFragmentManager.popBackStack()
        }

        binding.btnPsAnsDone.setOnClickListener {
            setPwForgetAns()
        }

    }

    private fun setPwForgetAns() {
        EPreferences.getInstance(requireContext()).putString(
            "fingerprint_forget_password",
            binding.edtVoiceAns.text.toString()
        )
        val saveAns = EPreferences.getInstance(requireContext())
            .getString("fingerprint_forget_password", "not get")
        if (saveAns == binding.edtVoiceAns.text.trim()
                .toString() && binding.edtVoiceAns.text.trim().isNotEmpty()
        ) {
            if (spinnerSelectName == "Please Select Question" && spinnerPosition == 0) {
                Log.d("spinnearPosition", spinnerPosition.toString())
                Toast.makeText(requireContext(), "Please select Question", Toast.LENGTH_SHORT)
                    .show()
            } else {
                Log.d("spinnearPosition", spinnerPosition.toString())
                requireActivity().supportFragmentManager.popBackStack()
            }
        } else {
            Toast.makeText(
                requireContext(),
                getString(R.string.please_enter_forget_password_ans),
                Toast.LENGTH_SHORT
            ).show()
        }
        EPreferences.getInstance(requireContext()).putString(
            "fingerprint_spinner_position",
            spinnerPosition.toString()
        )
        EPreferences.getInstance(requireContext()).putString(
            "fingerprint_spinner_position_name",
            spinnerSelectName.toString()
        )
    }

    private fun setupSpinner() {
        val items = resources.getStringArray(R.array.spinner_items)

        // Create a custom ArrayAdapter
        val adapter = object :
            ArrayAdapter<String>(requireContext(), android.R.layout.simple_spinner_item, items) {
            override fun getDropDownView(
                position: Int,
                convertView: View?,
                parent: ViewGroup
            ): View {
                val view = super.getDropDownView(position, convertView, parent)
                val textView = view.findViewById<TextView>(android.R.id.text1)

                // Set the text color for the dropdown items
                textView.setTextColor(
                    if (position == 0) ContextCompat.getColor(context, R.color.white)
                    else ContextCompat.getColor(context, R.color.white)
                )

                // Set padding for dropdown items (10dp converted to pixels)
                val padding = (10 * resources.displayMetrics.density).toInt()
                textView.setPadding(padding, padding, padding, padding)

                return view
            }

            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val view = super.getView(position, convertView, parent)
                val textView = view.findViewById<TextView>(android.R.id.text1)

                // Set text color for the currently selected item
                textView.setTextColor(ContextCompat.getColor(context, R.color.white))

                // Set padding for selected item (10dp converted to pixels)
                val padding = (10 * resources.displayMetrics.density).toInt()
                textView.setPadding(padding, padding, padding, padding)

                return view
            }

            override fun isEnabled(position: Int): Boolean {
                // Disable the first item (hint) from being selected
                return position != 0
            }
        }

        // Attach the adapter to the spinner
        binding.spinner.adapter = adapter

        // Handle item selection events
        binding.spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                if (position != 0) {
                    val selectedItem = items[position]
                    spinnerPosition = position
                    spinnerSelectName = selectedItem
                    Toast.makeText(context, "You selected: $selectedItem", Toast.LENGTH_SHORT)
                        .show()
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // No action needed
            }
        }
    }

}