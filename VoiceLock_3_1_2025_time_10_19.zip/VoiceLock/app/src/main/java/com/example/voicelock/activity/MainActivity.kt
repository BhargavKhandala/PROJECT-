package com.example.voicelock.activity

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.voicelock.Ads.Constant
import com.example.voicelock.EPreference.EPreferences
import com.example.voicelock.LockScreenService
import com.example.voicelock.R
import com.example.voicelock.databinding.ActivityMainBinding
import com.example.voicelock.fragment.SettingFragment
import com.google.android.gms.ads.AdRequest

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val REQUEST_RECORD_AUDIO_PERMISSION = 200
    private val REQUEST_PERMISSION_CODE = 1234
    private val REQUIRED_PERMISSIONS = arrayOf(
        Manifest.permission.CAMERA,
        Manifest.permission.ACCESS_FINE_LOCATION
    )
    private val REQUEST_FOREGROUND_SERVICE_MEDIA_PLAYBACK_PERMISSION = 1003

    private val notificationPermissionRequest = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            startLockScreenService()
        } else {
            Toast.makeText(this, "Notification permission is required", Toast.LENGTH_SHORT).show()
        }
    }

    private val requestOverlayPermission = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (Settings.canDrawOverlays(this)) {
            // Permission granted, proceed with starting the service
            startLockScreenService()
        } else {
            Toast.makeText(this, "Overlay permission is required", Toast.LENGTH_SHORT).show()
        }
    }

    private lateinit var constant: Constant

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadAds()
        init()
        addListener()
        checkLockPermission()
    }

    private fun loadAds() {
        constant = Constant()
        constant.loadRewardedAd(this)
        constant.loadNativeAds(this, R.id.fragment_native)

        val adRequest = AdRequest.Builder().build()
        binding.adView.loadAd(adRequest)

        constant.interstitialAdsLoad(this)
    }

    private fun hasPermissions(vararg permissions: String): Boolean {
        for (permission in permissions) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    permission
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                return false
            }
        }
        return true
    }

    private fun requestSystemAlertWindowPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(
                this,
                Manifest.permission.SYSTEM_ALERT_WINDOW
            )
        ) {
            Toast.makeText(this, "Permission needed to show lock screen overlay", Toast.LENGTH_LONG)
                .show()
        }

        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
        startActivityForResult(intent, REQUEST_PERMISSION_CODE)
    }

    private fun checkLockPermission() {
        if (Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "All permissions are already granted.", Toast.LENGTH_SHORT).show()
        } else {
            requestOverlayPermission()
        }

        if (!hasPermissions(*REQUIRED_PERMISSIONS)) {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, REQUEST_PERMISSION_CODE)
        }

        binding.sbLock.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                    ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.POST_NOTIFICATIONS
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    checkNotificationPermission()
                } else {
                    EPreferences.getInstance(this).putString("switchOn", "true")
                    checkAndRequestForegroundServiceMediaPlaybackPermission()
                }
            } else {
                EPreferences.getInstance(this).putString("switchOn", "false")
                stopLockScreenService()
            }
        }
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
            requestOverlayPermission.launch(intent)
        } else {
            // Permission already granted, proceed with starting the service
            startLockScreenService()
        }
    }

    private fun checkAndRequestForegroundServiceMediaPlaybackPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK),
                    REQUEST_FOREGROUND_SERVICE_MEDIA_PLAYBACK_PERMISSION
                )
            } else {
                startLockScreenService()
            }
        } else {
            startLockScreenService()
        }
    }

    private fun startLockScreenService() {
        val serviceIntent = Intent(this, LockScreenService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
        Toast.makeText(this, "Lock screen activated", Toast.LENGTH_SHORT).show()
    }

    private fun stopLockScreenService() {
        val serviceIntent = Intent(this, LockScreenService::class.java)
        stopService(serviceIntent)
        Toast.makeText(this, "Lock screen deactivated", Toast.LENGTH_SHORT).show()
    }

    private fun checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                startLockScreenService()
            } else {
                notificationPermissionRequest.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        } else {
            startLockScreenService()
        }
    }

    @SuppressLint("SetTextI18n")
    private fun addListener() {
        binding.sbLock.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                constant.nextActivityName = null
                constant.showRewardedAd(this)
                checkAndRequestForegroundServiceMediaPlaybackPermission()
            } else {
                constant.nextActivityName = null
                constant.showRewardedAd(this)
                stopLockScreenService()
            }
        }

        binding.layoutLock.rlHomeIcon.setOnClickListener {
            constant.nextActivityName = SetLockTypeActivity::class.java
            constant.showRewardedAd(this)
        }

        binding.layoutFingerprint.rlHomeIcon.setOnClickListener {
            constant.nextActivityName = FingerprintSetActivity::class.java
            constant.showInterstitialAds(this)
        }

        binding.layoutCustomization.rlHomeIcon.setOnClickListener {
            constant.nextActivityName = CustomizationActivity::class.java
            constant.showInterstitialAds(this)
        }

        binding.layoutLockThem.rlHomeIcon.setOnClickListener {
            constant.nextActivityName = LockThemesActivity::class.java
            constant.showInterstitialAds(this)
        }

        binding.imgMenuHome.setOnClickListener {
            openSettingFragment()
        }
    }

    private fun openSettingFragment() {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, SettingFragment())
            .addToBackStack(null)
            .commit()
        binding.svMainActivty.visibility = View.GONE
    }

    private fun init() {
        settingFragmnetToBackPress()
        if (!checkPermissions()) {
            requestPermissions()
        } else {
            setupLayoutIcons()
        }
        setSwitch()
    }

    private fun settingFragmnetToBackPress() {
        supportFragmentManager.addOnBackStackChangedListener {
            val fragment = supportFragmentManager.findFragmentById(R.id.fragment_container)
            if (fragment == null) {
                binding.svMainActivty.visibility = View.VISIBLE
            } else {
                binding.svMainActivty.visibility = View.GONE
            }
        }
    }

    private fun setSwitch() {
        val switchChange = EPreferences.getInstance(this).getString("switchOn", "false")
        binding.sbLock.isChecked = switchChange == "true"
    }

    private fun setupLayoutIcons() {
        binding.layoutLockThem.imgLayoutLock.setImageResource(R.drawable.ic_themes)
        binding.layoutLockThem.tvLayoutIconName.text = getString(R.string.lock_themes)

        binding.layoutFingerprint.imgLayoutLock.setImageResource(R.drawable.ic_firgerprint)
        binding.layoutFingerprint.tvLayoutIconName.text = getString(R.string.fingerprint)

        binding.layoutCustomization.imgLayoutLock.setImageResource(R.drawable.ic_customazication)
        binding.layoutCustomization.tvLayoutIconName.text = getString(R.string.customization)
    }

    private fun checkPermissions(): Boolean {
        return ActivityCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED &&
                (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE ||
                        ActivityCompat.checkSelfPermission(
                            this,
                            Manifest.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK
                        ) == PackageManager.PERMISSION_GRANTED)
    }

    private fun requestPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.USE_BIOMETRIC,
            Manifest.permission.USE_FINGERPRINT
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            permissions.add(Manifest.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK)
        }

        ActivityCompat.requestPermissions(
            this,
            permissions.toTypedArray(),
            REQUEST_RECORD_AUDIO_PERMISSION
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQUEST_RECORD_AUDIO_PERMISSION -> {
                if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                    setupLayoutIcons()
                } else {
                    Toast.makeText(this, "Permission denied 1!", Toast.LENGTH_SHORT).show()
                }
            }
            REQUEST_FOREGROUND_SERVICE_MEDIA_PLAYBACK_PERMISSION -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    startLockScreenService()
                } else {
                    Toast.makeText(this, "Permission denied 2!", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}