package com.example.voicelock.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.voicelock.R
import com.example.voicelock.model.LanguageModel
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError

class LanguageAdapter(
    private val context: Context,
    private val languageList: List<LanguageModel>,
    private val onItemClick: (LanguageModel) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val VIEW_TYPE_LANGUAGE = 0
        private const val VIEW_TYPE_AD = 1
        private const val AD_INTERVAL = 4 // Show ad after every 2 items
    }

    private var selectedPosition: Int = RecyclerView.NO_POSITION

    override fun getItemViewType(position: Int): Int {
        return if ((position + 1) % (AD_INTERVAL + 1) == 0 && position != 0) {
            VIEW_TYPE_AD
        } else {
            VIEW_TYPE_LANGUAGE
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            VIEW_TYPE_LANGUAGE -> {
                val view = LayoutInflater.from(context).inflate(R.layout.item_language, parent, false)
                LanguageViewHolder(view)
            }
            VIEW_TYPE_AD -> {
                val view = LayoutInflater.from(context).inflate(R.layout.item_banner_ad, parent, false)
                AdViewHolder(view)
            }
            else -> throw IllegalArgumentException("Invalid view type")
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, @SuppressLint("RecyclerView") position: Int) {
        when (holder) {
            is LanguageViewHolder -> {
                val adjustedPosition = position - (position / (AD_INTERVAL + 1))
                val language = languageList[adjustedPosition]

                // Bind the language data to the views
                holder.bind(language, position == selectedPosition)

                // Set the RadioButton state and background resource
                if (position == selectedPosition) {
                    holder.radioButton.isChecked = true
                    holder.radioButton.setBackgroundResource(R.drawable.ic_ok_white)
                } else {
                    holder.radioButton.isChecked = false
                    holder.radioButton.setBackgroundResource(R.drawable.cust_radio_button)
                }

                // Set click listeners
                holder.itemView.setOnClickListener {
                    selectedPosition = position
                    notifyDataSetChanged() // Refresh the RecyclerView to update the UI
                    onItemClick(language)
                }

                holder.radioButton.setOnClickListener {
                    selectedPosition = position
                    notifyDataSetChanged() // Refresh the RecyclerView to update the UI
                    onItemClick(language)
                }
            }
            is AdViewHolder -> {
                // Load the ad here
                holder.loadAd()
            }
        }
    }

    override fun getItemCount(): Int {
        // Add extra items for ads
        return languageList.size + (languageList.size / AD_INTERVAL)
    }

    inner class LanguageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val languageName: TextView = itemView.findViewById(R.id.tvLanguage)
        val languageIcon: ImageView = itemView.findViewById(R.id.ivCountryImage)
        val radioButton: RadioButton = itemView.findViewById(R.id.viewCheck)

        fun bind(language: LanguageModel, isSelected: Boolean) {
            languageName.text = language.languageName
            languageIcon.setImageResource(language.iconResId)
            radioButton.isChecked = isSelected
        }
    }
    inner class AdViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val adView: AdView = itemView.findViewById(R.id.adView)
        private val rlAds: RelativeLayout = itemView.findViewById(R.id.rlAds)

        fun loadAd() {
            val adRequest = AdRequest.Builder().build()

            // Set an AdListener to handle ad events
            adView.adListener = object : AdListener() {
                override fun onAdLoaded() {
                }

                override fun onAdFailedToLoad(adError: LoadAdError) {
                    // Handle ad load failure (optional)
                }
            }

            // Load the ad
            adView.loadAd(adRequest)

        }
    }
}