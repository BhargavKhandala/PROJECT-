package com.example.voicelock.fragment

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import com.example.voicelock.R
import com.example.voicelock.activity.WallpaperSetActivity
import com.example.voicelock.adapter.FingerprintAdapter
import com.example.voicelock.database.DatabaseHelper
import com.example.voicelock.database.model.TaskIsModel
import com.example.voicelock.databinding.FragmentFingerprintThemeBinding


class FingerprintThemeFragment : Fragment() , FingerprintAdapter.OnItemClickListener{

    private lateinit var binding : FragmentFingerprintThemeBinding
    private val REQUEST_IMAGE_PICK = 1001
    private val imageList = mutableListOf<Uri>()
    private lateinit var adapter : FingerprintAdapter
    private var dbHandle : DatabaseHelper? = null
    private var TABLE_NAME = "fingerprint"
    private var taskIsModel : List<TaskIsModel> = ArrayList<TaskIsModel> ()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentFingerprintThemeBinding.inflate(inflater, container, false)
        init()
        addListener()
        return binding.root
    }

    private fun addListener() {
        binding.imgAddGallery.setOnClickListener {
            binding.pdWallpaperThemes.visibility = View.VISIBLE
            binding.overlayView.visibility = View.VISIBLE
            openGallery()
        }
    }

    private fun init() {
        dbHandle = DatabaseHelper(requireContext(), TABLE_NAME)
        dbHandle!!.createTable(dbHandle!!.writableDatabase,TABLE_NAME)
        setRecycleVIew()
        loadImagesFromDatabase()
    }

    private fun setRecycleVIew() {
        binding.rvGallery.layoutManager = GridLayoutManager(requireContext(),1)
        adapter = FingerprintAdapter(requireContext(),imageList,this)
        binding.rvGallery.adapter = adapter
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        if (intent.resolveActivity(requireActivity().packageManager) != null) {
            startActivityForResult(intent, REQUEST_IMAGE_PICK)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_PICK && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->
                imageList.add(uri) // Add selected image URI to list
                adapter.notifyDataSetChanged() // Update RecyclerView
                insetImageDatabase(uri)
            }
        }

        if (requestCode == 2001 && resultCode == Activity.RESULT_OK) {
            val deletedUri = data?.getStringExtra("delete_image") ?: return
            val uriToRemove = Uri.parse(deletedUri)

            Log.d("delete_image", "Deleted Image URI: $deletedUri")

            if (imageList.contains(uriToRemove)) {
                imageList.remove(uriToRemove)
                adapter.notifyDataSetChanged()
            }

            // Refresh the images from the database
            loadImagesFromDatabase()
        }
    }

    private fun insetImageDatabase(uri: Uri) {
        val success : Boolean
        val task = TaskIsModel()
        task.image = uri.toString()
        success = dbHandle!!.addTask(task)
        if (success){
            Toast.makeText(requireContext(),"Add Image  : $imageList",Toast.LENGTH_SHORT)
            Log.d("taskIsModel",success.toString())
        } else{
            Toast.makeText(requireContext(),"Not add image",Toast.LENGTH_SHORT)
        }
    }

    private fun loadImagesFromDatabase() {
        imageList.clear()
        taskIsModel = dbHandle!!.getAllTask()
        for (task in taskIsModel)
            task.image.let { imageUri ->
                imageList.add(Uri.parse(imageUri))
            }
        adapter.notifyDataSetChanged()
    }

    override fun onItemClick(imageUri: Uri) {
            val intent = Intent(requireContext(), WallpaperSetActivity::class.java)
            intent.putExtra("wallpaper_uri", imageUri.toString()) // Convert Uri to String
            intent.putExtra("table_name", TABLE_NAME) // Convert Uri to String
            startActivityForResult(intent, 2001) // Use a request code (e.g., 2001)
    }

    override fun onResume() {
        super.onResume()
        binding.pdWallpaperThemes.visibility = View.GONE
        binding.overlayView.visibility = View.GONE
    }

}