package com.example.voicelock.activity

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.voicelock.EPreference.EPreferences
import com.example.voicelock.PatterLockScreen
import com.example.voicelock.R
import com.example.voicelock.databinding.ActivityLockHomeScreenBinding

class LockHomeScreenActivity : AppCompatActivity() , PatterLockScreen.OnItemClickListener{

    private lateinit var binding : ActivityLockHomeScreenBinding
    private var lockType: String? = null
    private var enteredPin = ""
    private var preEnteredPin = ""
    private var preComplexLock = ""
    private var wallpaperUri = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLockHomeScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.patternLockView.homeLockScreen = this

        init()
        addListener()

    }

    private fun addListener() {
        binding.layoutTbPinLock.imgBackPress.setOnClickListener {
            finish()
        }
        digitClick()
        binding.imgCancelLastDigit.setOnClickListener { removeDigit() }
        binding.btnPinPsDone.setOnClickListener {
            if (enteredPin.length == 4) {
                if (enteredPin == preEnteredPin){
                    val finishIntent = Intent("ACTION_FINISH_ALL")
                    sendBroadcast(finishIntent)
                    finish()
                } else {
                    enteredPin = ""
                    updatePinIndicators()
                    Toast.makeText(this,
                        getString(R.string.incorrect_pin_please_try_again), Toast.LENGTH_SHORT).show()
                }

            }}

        binding.btnComplexPsDone.setOnClickListener {
          val edtComplexLock = binding.edtComplex.text.trim().toString()
            if (edtComplexLock.isEmpty()){
                Toast.makeText(this,getString(R.string.please_enter_pin),Toast.LENGTH_SHORT).show()
            } else{
                if (edtComplexLock == preComplexLock){
                    val finishIntent = Intent("ACTION_FINISH_ALL")
                    sendBroadcast(finishIntent)
                    finish()
                } else{
                    binding.edtComplex.text = null
                    Toast.makeText(this,
                        getString(R.string.incorrect_pin_please_try_again), Toast.LENGTH_SHORT).show()
                }
            }
        }

    }

    private fun init(){
        setLayoutLockType()
        setWallpaper()
        setTbText()
        setDigitText()
        getLockTypeANdSet()
    }

    private fun setWallpaper() {
        Log.d("wallpaperImage","Image : ${wallpaperUri}")
        if (wallpaperUri.isNullOrEmpty()) {
            Log.e("WallpaperSetActivity", "imageUri is null or empty")
            return
        }

        Log.d("WallpaperSetActivity", "Received imageUri: $wallpaperUri") // Check the format in Logcat

        try {
            Glide.with(this)
                .load(Uri.parse(wallpaperUri)) // Convert back to Uri correctly
                .into(binding.imgWallpaper)
        } catch (e: Exception) {
            Log.e("WallpaperSetActivity", "Error loading image with Glide", e)
        }}

    private fun setLayoutLockType() {
        lockType = intent.getStringExtra("lock_type")

        if (lockType == "Pin Lock") {
            wallpaperUri = EPreferences.getInstance(this).getString("PinLock","").toString()
            binding.llComplexLock.visibility = View.GONE
            binding.rlPatterLock.visibility = View.GONE
            binding.llPinLock.visibility = View.VISIBLE
        } else if (lockType == "Complex Lock") {
            wallpaperUri = EPreferences.getInstance(this).getString("ComplexLock","").toString()
            binding.llPinLock.visibility = View.GONE
            binding.rlPatterLock.visibility = View.GONE
            binding.llComplexLock.visibility = View.VISIBLE
        } else if (lockType == "Pattern Lock") {
            wallpaperUri = EPreferences.getInstance(this).getString("PatternLock","").toString()
            binding.llPinLock.visibility = View.GONE
            binding.llComplexLock.visibility = View.GONE
            binding.rlPatterLock.visibility = View.VISIBLE
        }
    }


    @SuppressLint("SetTextI18n")
    private fun setTbText() {
        binding.layoutTbPinLock.tvTbName.visibility = View.GONE
    }

    private fun setDigitText() {
        binding.btnOnePin.tvPinText.text = getString(R.string._1)
        binding.btnSecondPin.tvPinText.text = getString(R.string._2)
        binding.btnThreePin.tvPinText.text = getString(R.string._3)
        binding.btnFourPin.tvPinText.text = getString(R.string._4)
        binding.btnFivePin.tvPinText.text = getString(R.string._5)
        binding.btnSixPin.tvPinText.text = getString(R.string._6)
        binding.btnSevenPin.tvPinText.text = getString(R.string._7)
        binding.btnEightPin.tvPinText.text = getString(R.string._8)
        binding.btnNinePin.tvPinText.text = getString(R.string._9)
        binding.btnGiroPin.tvPinText.text = getString(R.string._0)
    }

    private fun addDigit(digit: String) {
        if (enteredPin.length < 4) {
            enteredPin += digit
            updatePinIndicators()
        }
    }

    private fun removeDigit() {
        if (enteredPin.isNotEmpty()) {
            enteredPin = enteredPin.dropLast(1)
            updatePinIndicators()
        }
    }

    private fun updatePinIndicators() {
        val pinLength = enteredPin.length

        // Update image resources for each PIN indicator
        binding.pinDigit1.setImageResource(if (pinLength > 0) R.drawable.pin_enter_ps_drawable else R.drawable.pin_enter_ps_blank_drawable)
        binding.pinDigit2.setImageResource(if (pinLength > 1) R.drawable.pin_enter_ps_drawable else R.drawable.pin_enter_ps_blank_drawable)
        binding.pinDigit3.setImageResource(if (pinLength > 2) R.drawable.pin_enter_ps_drawable else R.drawable.pin_enter_ps_blank_drawable)
        binding.pinDigit4.setImageResource(if (pinLength > 3) R.drawable.pin_enter_ps_drawable else R.drawable.pin_enter_ps_blank_drawable)
    }


    private fun digitClick() {
        // Set click listeners for the PIN buttons
        binding.btnOnePin.llPinBg.setOnClickListener { addDigit("1") }
        binding.btnSecondPin.llPinBg.setOnClickListener { addDigit("2") }
        binding.btnThreePin.llPinBg.setOnClickListener { addDigit("3") }
        binding.btnFourPin.llPinBg.setOnClickListener { addDigit("4") }
        binding.btnFivePin.llPinBg.setOnClickListener { addDigit("5") }
        binding.btnSixPin.llPinBg.setOnClickListener { addDigit("6") }
        binding.btnSevenPin.llPinBg.setOnClickListener { addDigit("7") }
        binding.btnEightPin.llPinBg.setOnClickListener { addDigit("8") }
        binding.btnNinePin.llPinBg.setOnClickListener { addDigit("9") }
        binding.btnGiroPin.llPinBg.setOnClickListener { addDigit("0") }
    }

    private fun getLockTypeANdSet() {
        if (lockType == "Pin Lock"){
            preEnteredPin = EPreferences.getInstance(this).getString("pin_password", "null").toString()
        } else (lockType == "Complex Lock")
        preComplexLock = EPreferences.getInstance(this).getString("Complex_lock_password", "null").toString()
    }

    override fun textColorSet(value: Boolean) {
        if (value){
            val finishIntent = Intent("ACTION_FINISH_ALL")
            sendBroadcast(finishIntent)
            finish()
            Toast.makeText(this,getString(R.string.mach_password),Toast.LENGTH_SHORT).show()
        } else{
            Toast.makeText(this,getString(R.string.not_match_complex_password_try_again),Toast.LENGTH_SHORT).show()
            binding.tvPassword.text = getString(R.string.wrong_pattern)
            binding.tvPassword.setTextColor(Color.RED)
        }

    }


}