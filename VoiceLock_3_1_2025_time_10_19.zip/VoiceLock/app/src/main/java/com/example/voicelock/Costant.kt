package com.example.voicelock

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView

class Costant(private val context: Context) {

     fun securingDeviceDialog() {
        val layoutInflater = LayoutInflater.from(context)
        // Inflate the custom layout
        val dialogView = layoutInflater.inflate(R.layout.securing_your_device_dialog, null)

        // Create the dialog
        val dialog = android.app.AlertDialog.Builder(context)
            .setView(dialogView)
            .setCancelable(false)
            .create()

        dialog.window?.setBackgroundDrawableResource(R.drawable.securing_device_drawable)

        // Find views in the dialog
        val successMessage = dialogView.findViewById<TextView>(R.id.successMessage)
        val seekBar = dialogView.findViewById<SeekBar>(R.id.sbSpaceScreen)

        seekBar.setOnTouchListener { _, _ -> true }

        // Initialize SeekBar
        seekBar.max = 100
        seekBar.progress = 0

        // Start SeekBar progress animation for 5 seconds
        val duration = 3000 // 5 seconds in milliseconds
        val updateInterval = 50 // Interval for SeekBar updates in milliseconds

        val handler = Handler(Looper.getMainLooper())
        val startTime = System.currentTimeMillis()

        val runnable = object : Runnable {
            override fun run() {
                val elapsedTime = System.currentTimeMillis() - startTime
                val progress = (elapsedTime * 100 / duration).toInt()

                if (progress < 100) {
                    seekBar.progress = progress
                    handler.postDelayed(this, updateInterval.toLong())
                } else {
                    seekBar.progress = 100
                    dialog.dismiss()
                    successDialogBox()
                }
            }
        }

        handler.post(runnable)


        // Show the dialog
        dialog.show()
    }

    @SuppressLint("MissingInflatedId")
    fun successDialogBox(){
        val layoutInflater = LayoutInflater.from(context)
        // Inflate the custom layout
        val dialogView = layoutInflater.inflate(R.layout.seccess_dialog, null)

        // Create the dialog
        val dialog = android.app.AlertDialog.Builder(context)
            .setView(dialogView)
            .setCancelable(false)
            .create()

        dialog.window?.setBackgroundDrawableResource(R.drawable.securing_device_drawable)

        // Find views in the dialog
        val btnContinue = dialogView.findViewById<Button>(R.id.btnContinueDialog)

        btnContinue.setOnClickListener {
            dialog.dismiss() // Close the dialog
            if (context is Activity) {
                context.finish() // Close the current activity
            }
        }

        // Show the dialog
        dialog.show()
    }
}