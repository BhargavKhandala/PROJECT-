package com.example.voicelock.activity

import android.app.Activity
import android.app.ComponentCaller
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.voicelock.EPreference.EPreferences
import com.example.voicelock.LockWallpaperAdapter
import com.example.voicelock.database.DatabaseHelper
import com.example.voicelock.database.model.TaskIsModel
import com.example.voicelock.databinding.ActivityLockWallpaperBinding
import kotlinx.coroutines.launch

class LockWallpaperActivity : AppCompatActivity(), LockWallpaperAdapter.OnItemClickListener {

    private lateinit var binding: ActivityLockWallpaperBinding
    private val REQUEST_IMAGE_PICK = 1001
    private val imageList = mutableListOf<Uri>()
    private lateinit var adapter: LockWallpaperAdapter
    private var taskIsModel : List<TaskIsModel> = ArrayList<TaskIsModel> ()
    private var dbHandle :DatabaseHelper? = null
    private var dbTableName = "lockWallpaper"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLockWallpaperBinding.inflate(layoutInflater)
        setContentView(binding.root)

Log.d("one","one")

        init()
        addListener()
    }

    private fun init() {
        dbHandle = DatabaseHelper(this, dbTableName)
        dbHandle!!.createTable(dbHandle!!.writableDatabase, dbTableName)
        setupRecyclerView()
        loadImagesFromDatabase()
    }

    private fun setupRecyclerView() {
        adapter = LockWallpaperAdapter(this, imageList, this)
        binding.rvWallpaper.layoutManager = GridLayoutManager(this, 2)
        binding.rvWallpaper.adapter = adapter
    }

    private fun addListener() {
        binding.imgBack.setOnClickListener {
            finish()
        }
        binding.imgAdd.setOnClickListener {
            binding.pbWallpaper.visibility = View.VISIBLE
            binding.overlayView.visibility = View.VISIBLE
            openGallery()
        }
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        if (intent.resolveActivity(packageManager) != null) {
            startActivityForResult(intent, REQUEST_IMAGE_PICK)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_PICK && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->
                imageList.add(uri) // Add selected image URI to list
                adapter.notifyDataSetChanged() // Update RecyclerView
                insetImageRoomDatabase(uri)
            }
        }

        if (requestCode == 2001 && resultCode == Activity.RESULT_OK) {
            val deletedUri = data?.getStringExtra("delete_image") ?: return
            val uriToRemove = Uri.parse(deletedUri)

            Log.d("delete_image", "Deleted Image URI: $deletedUri")

            if (imageList.contains(uriToRemove)) {
                imageList.remove(uriToRemove)
                adapter.notifyDataSetChanged()
            }

            // Refresh the images from the database
            loadImagesFromDatabase()
        }
    }

    private fun insetImageRoomDatabase(uri: Uri) {
        val success : Boolean
        val task = TaskIsModel()
        task.image = uri.toString()
        success = dbHandle!!.addTask(task)
        if (success){
            Toast.makeText(this,"Add Image  : $imageList",Toast.LENGTH_SHORT)
            Log.d("taskIsModel",success.toString())
        } else{
            Toast.makeText(this,"Not add image",Toast.LENGTH_SHORT)
        }


//        val wallpaperData = WallpaperData(wallpaperUri = uri.toString()) // Convert Uri to String
//        lifecycleScope.launch {
//            WallpaperDatabase.getDatabase(this@LockWallpaperActivity).wallpaperDao()
//                .insertImageUri(wallpaperData)
//            Toast.makeText(this@LockWallpaperActivity, "User Added", Toast.LENGTH_SHORT).show()
//        }
    }

    private fun loadImagesFromDatabase() {
        imageList.clear()
        taskIsModel = dbHandle!!.getAllTask()
        for (task in taskIsModel)
            task.image.let { imageUri ->
                imageList.add(Uri.parse(imageUri))
            }
                    adapter.notifyDataSetChanged()


//        lifecycleScope.launch {
//            val images = WallpaperDatabase.getDatabase(this@LockWallpaperActivity).wallpaperDao()
//                .getAllImages()
//            imageList.clear()
//            imageList.addAll(images.map { Uri.parse(it.wallpaperUri) }) // Convert String back to Uri
//            adapter.notifyDataSetChanged()
//        }
    }

    override fun onItemClick(imageUri: Uri) {
        val intent = Intent(this, WallpaperSetActivity::class.java)
        intent.putExtra("wallpaper_uri", imageUri.toString()) // Convert Uri to String
        intent.putExtra("table_name", dbTableName) // Convert Uri to String
        startActivityForResult(intent, 2001) // Use a request code (e.g., 2001)
    }

    override fun onResume() {
        super.onResume()
        binding.pbWallpaper.visibility = View.GONE
        binding.overlayView.visibility = View.GONE
        Log.d("one","one 1")
    }


}