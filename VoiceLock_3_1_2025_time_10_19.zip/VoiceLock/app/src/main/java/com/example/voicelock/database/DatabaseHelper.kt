package com.example.voicelock.database

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.voicelock.database.model.TaskIsModel

class DatabaseHelper(context: Context, private val TABLE_NAME : String) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    companion object {
        private const val DB_NAME = "task"
        private const val DB_VERSION = 4  // Increased to trigger table recreation
        private const val IMAGE_URI = "taskname"  // Corrected column name
    }

    override fun onCreate(db: SQLiteDatabase?) {
      createTable(db,TABLE_NAME)
    }

    fun createTable(db: SQLiteDatabase?, tableName: String) {
        val CREATE_TABLE = "CREATE TABLE IF NOT EXISTS $TABLE_NAME ($IMAGE_URI TEXT)"
        db?.execSQL(CREATE_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    @SuppressLint("Range")
    fun getAllTask(): List<TaskIsModel> {
        val taskList = ArrayList<TaskIsModel>()
        val db = readableDatabase
        val selectQuery = "SELECT * FROM $TABLE_NAME"
        val cursor = db.rawQuery(selectQuery, null)

        cursor.use {
            if (it.moveToFirst()) {
                do {
                    val task = TaskIsModel()
                    val imageUri = it.getColumnIndex(IMAGE_URI)

                    if (imageUri != -1) task.image = it.getString(imageUri)

                    taskList.add(task)
                } while (it.moveToNext())
            }
        }
        return taskList
    }

    fun addTask(task: TaskIsModel): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(IMAGE_URI, task.image)
        }

        val success = db.insert(TABLE_NAME, null, values)
        db.close()
        return success != -1L
    }

    fun deleteTask(imageUri: String ): Boolean {
        val db = writableDatabase
        val success = db.delete(TABLE_NAME, "$IMAGE_URI=?", arrayOf(imageUri.toString()))
        db.close()
        return success != -1
    }


//    @SuppressLint("Range")
//    fun getTask(_id: Int): TaskIsModel? {
//        val db = readableDatabase
//        val selectQuery = "SELECT * FROM $TABLE_NAME WHERE $ID = ?"
//        val cursor = db.rawQuery(selectQuery, arrayOf(_id.toString()))
//
//        return cursor.use {
//            if (it.moveToFirst()) {
//                val task = TaskIsModel()
//                val idIndex = it.getColumnIndex(ID)
//                val nameIndex = it.getColumnIndex(TASK_NAME)
//                val detailsIndex = it.getColumnIndex(TASK_DETAILS)
//
//                if (idIndex != -1) task.id = it.getInt(idIndex)
//                if (nameIndex != -1) task.name = it.getString(nameIndex)
//                if (detailsIndex != -1) task.details = it.getString(detailsIndex)
//
//                task
//            } else null
//        }
//    }
//

//    fun updateTask(task: TaskIsModel): Boolean {
//        val db = writableDatabase
//        val values = ContentValues().apply {
//            put(TASK_NAME, task.name)
//            put(TASK_DETAILS, task.details)
//        }
//
//        val success = db.update(TABLE_NAME, values, "$ID=?", arrayOf(task.id.toString()))
//        db.close()
//        return success != -1
//    }
}
