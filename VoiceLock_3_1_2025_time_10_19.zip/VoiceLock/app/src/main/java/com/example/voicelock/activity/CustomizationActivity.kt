package com.example.voicelock.activity

import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import androidx.appcompat.app.AppCompatActivity
import com.example.voicelock.EPreference.EPreferences
import com.example.voicelock.R
import com.example.voicelock.databinding.ActivityCustomizationBinding
import com.example.voicelock.fragment.PasswordForgetAnsFragment

class CustomizationActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCustomizationBinding
    private val REQUEST_IMAGE_PICK = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCustomizationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        init()
        addListener()
    }

    private fun addListener() {
        dateTimeSwitch()
        binding.layoutTbPinLock.imgBackPress.setOnClickListener { finish() }
        binding.rlPreview.setOnClickListener {
            fragmentPreview()
        }

        binding.rlLockWallpaper.setOnClickListener {
            startActivity(Intent(this,LockWallpaperActivity::class.java))
        }
    }


    private fun fragmentPreview() {
        val fragment = PreviewFragment()

        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(
            R.id.fragment_container,
            fragment
        ) // Replace the container with the new fragment
        transaction.addToBackStack(null) // Optional: add this transaction to the back stack for back navigation
        transaction.commit()
    }

    private fun dateTimeSwitch() {
        binding.sbLockDateTime.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked)
                EPreferences.getInstance(this).putBoolean("date_time_show", true)
            else
                EPreferences.getInstance(this).putBoolean("date_time_show", false)
        }
    }

    private fun init() {
        setTbText()
        setDateTime()
    }

    private fun setTbText() {
        binding.layoutTbPinLock.tvTbName.text = getString(R.string.customization)
    }

    private fun setDateTime() {
        val setDate = EPreferences.getInstance(this).getBoolean("date_time_show", true)
        binding.sbLockDateTime.isChecked = setDate
    }


}